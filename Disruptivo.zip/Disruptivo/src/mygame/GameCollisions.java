package mygame;

import java.util.ArrayList;

/**
 * Aquí están TODAS las colisiones manuales de muebles.
 *
 * Estas colisiones NO son las paredes.
 * Las paredes están en la matriz collision de cada escena.
 *
 * Aquí usamos Rect(x, y, ancho, alto):
 * - x mueve izquierda/derecha
 * - y mueve arriba/abajo
 * - w cambia ancho
 * - h cambia alto
 */
public class GameCollisions {

    /**
     * Limpia y carga las colisiones de muebles de la escena actual.
     *
     * @param sceneName nombre de la escena
     * @param furnitureBlocks lista donde se guardan las colisiones
     */
    public static void setupFurnitureCollisions(String sceneName, ArrayList<Rect> furnitureBlocks) {
        furnitureBlocks.clear();

        if (sceneName.equals("ROOM")) {
            addRoomFurnitureCollisions(furnitureBlocks);
        } else if (sceneName.equals("NURSING")) {
            addNursingFurnitureCollisions(furnitureBlocks);
        } else if (sceneName.equals("DOCTORS")) {
            addDoctorsFurnitureCollisions(furnitureBlocks);
        } else if (sceneName.equals("THERAPIST")) {
            addTherapistFurnitureCollisions(furnitureBlocks);
        } else if (sceneName.equals("RECEPTION")) {
            addReceptionFurnitureCollisions(furnitureBlocks);
        } else if (sceneName.equals("HALLWAY")) {
            addHallwayFurnitureCollisions(furnitureBlocks);
        }
    }

    private static void addRoomFurnitureCollisions(ArrayList<Rect> furnitureBlocks) {
        // Cuarto de Rupert.
        furnitureBlocks.add(new Rect(34, 45, 28, 35));    // cama / mueble izquierdo
        furnitureBlocks.add(new Rect(110, 43, 20, 35));   // silla / objeto superior
        furnitureBlocks.add(new Rect(65, 112, 30, 10));   // mesa / mueble del centro bajo
        furnitureBlocks.add(new Rect(70, 100, 17, 40));   // parte baja del mueble
    }

    private static void addNursingFurnitureCollisions(ArrayList<Rect> furnitureBlocks) {
        // Enfermería.
        furnitureBlocks.add(new Rect(34, 45, 26, 35));    // cama izquierda arriba
        furnitureBlocks.add(new Rect(100, 45, 26, 35));   // cama centro arriba
        furnitureBlocks.add(new Rect(167, 35, 58, 36));   // mesa
        furnitureBlocks.add(new Rect(34, 132, 26, 35));   // cama izquierda abajo
        furnitureBlocks.add(new Rect(162, 132, 26, 35));  // cama derecha abajo
        furnitureBlocks.add(new Rect(116, 42, 30, 35));   // mesa grande derecha
        furnitureBlocks.add(new Rect(50, 42, 30, 35));
        furnitureBlocks.add(new Rect(50, 144, 30, 35));
        furnitureBlocks.add(new Rect(178, 144, 30, 35));
    }

    private static void addDoctorsFurnitureCollisions(ArrayList<Rect> furnitureBlocks) {
        // Oficina de doctores.
        furnitureBlocks.add(new Rect(50, 45, 33, 35));    // escritorio/camilla izquierda
        furnitureBlocks.add(new Rect(130, 95, 30, 25));   // tapete/mesa centro
        furnitureBlocks.add(new Rect(160, 111, 16, 10));  // mesa derecha
    }

    private static void addTherapistFurnitureCollisions(ArrayList<Rect> furnitureBlocks) {
        // Consultorio terapeuta.
        furnitureBlocks.add(new Rect(32, 64, 32, 32));    // sillón / mueble izquierdo
        furnitureBlocks.add(new Rect(112, 80, 16, 16));   // mesa centro
        furnitureBlocks.add(new Rect(34, 125, 32, 28));   // planta/mesa abajo
    }

    private static void addReceptionFurnitureCollisions(ArrayList<Rect> furnitureBlocks) {
        // Recepción.
        furnitureBlocks.add(new Rect(48, 80, 72, 28));    // parte horizontal del mostrador
        furnitureBlocks.add(new Rect(96, 144, 96, 16));   // mueble / escritorio de la derecha
        furnitureBlocks.add(new Rect(208, 86, 16, 64));   // sillas de la derecha
    }

    private static void addHallwayFurnitureCollisions(ArrayList<Rect> furnitureBlocks) {
        // Pasillo sin muebles bloqueantes por ahora.
    }

    /**
     * Zonas donde Rupert se puede esconder con la tecla E.
     * Normalmente son las partes bajas de las camas.
     *
     * Si una cama no queda exacta, mueve los Rect igual que las colisiones:
     * Rect(x, y, ancho, alto).
     */
    public static void setupBedHideSpots(String sceneName, ArrayList<Rect> bedHideSpots) {
        bedHideSpots.clear();

        if (sceneName.equals("ROOM")) {
            // En el cuarto de Rupert, cama/mueble del lado izquierdo.
            bedHideSpots.add(new Rect(30, 50, 38, 38));

        } else if (sceneName.equals("NURSING")) {
            // Camas de enfermería.
            // La cama superior izquierda NO se usa para esconderse porque ahora
            // tendrá una interacción de nota/personaje.
            bedHideSpots.add(new Rect(96, 44, 38, 44));
            bedHideSpots.add(new Rect(30, 130, 38, 44));
            bedHideSpots.add(new Rect(158, 130, 38, 44));

        } else if (sceneName.equals("DOCTORS")) {
            // Camilla/escritorio del consultorio de doctores.
            bedHideSpots.add(new Rect(42, 44, 46, 40));

        } else if (sceneName.equals("THERAPIST")) {
            // Sillón/camilla del terapeuta.
            bedHideSpots.add(new Rect(28, 60, 42, 40));
        }
    }

}
