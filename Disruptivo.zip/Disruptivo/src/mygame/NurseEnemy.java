package mygame;

import com.jme3.app.SimpleApplication;
import com.jme3.material.Material;
import com.jme3.material.RenderState;
import com.jme3.math.Vector3f;
import com.jme3.renderer.queue.RenderQueue;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.VertexBuffer;
import com.jme3.scene.shape.Quad;
import com.jme3.texture.Texture;
import com.jme3.util.BufferUtils;
import java.nio.FloatBuffer;

/**
 * Enemigo del hospital.
 *
 * La enfermera puede:
 * - patrullar el pasillo sin reiniciarse cada vez que Rupert entra a un cuarto,
 * - ver solamente hacia donde está mirando,
 * - perseguir a Rupert si lo ve,
 * - seguirlo dentro de las habitaciones si ya lo estaba persiguiendo,
 * - perderlo si Rupert se esconde debajo de una cama.
 */
public class NurseEnemy {

    private final float TILE = 32f;

    /** Tamaño visual del sprite. */
    private final float SPRITE_SIZE = 32f;

    /** Caja invisible de colisión de la enfermera. */
    private final float HITBOX_W = 14f;
    private final float HITBOX_H = 16f;

    /** Spritesheet: 24 frames en una fila. */
    private final int COLUMNS = 24;
    private final int ROWS = 1;
    private final int FRAMES_PER_DIRECTION = 6;

    /** Velocidades. */
    private final float PATROL_SPEED = 38f;
    private final float CHASE_SPEED = 75f;
    private final float ANIM_SPEED = 0.12f;

    /** Campo de visión en pixeles. */
    private final float VISION_DISTANCE = TILE * 5f;
    private final float VISION_WIDTH = TILE * 1.2f;

    private final SimpleApplication app;
    private final Texture texture;

    private final Node enemyNode = new Node("NurseEnemy");
    private Geometry sprite;

    /**
     * active = la enfermera está viva y actualizándose.
     * visible = se dibuja en la escena actual.
     * chasing = está persiguiendo al jugador.
     */
    private boolean active = true;
    private boolean visible = false;
    private boolean chasing = false;

    private Direction direction = Direction.RIGHT;

    private float animTimer = 0f;
    private int currentFrame = 6;

    /** Límites de patrulla dentro del pasillo. */
    private float patrolMinX = 2 * TILE;
    private float patrolMaxX = 17 * TILE;
    private float patrolY = -3 * TILE;

    /** Configuración inicial para poder tener varias enfermeras con rutas diferentes. */
    private float patrolStartX = 9 * TILE;
    private Direction startDirection = Direction.RIGHT;

    /** Sirve para saber si ya se colocó una vez en el pasillo. */
    private boolean placedInHallway = false;

    /**
     * Cuando Rupert entra a un cuarto mientras la enfermera lo persigue,
     * NO debe aparecer instantáneamente. Primero se calcula cuánto tardaría
     * en llegar a la puerta desde donde estaba patrullando en el pasillo.
     */
    private boolean waitingToEnterRoom = false;
    private String pendingRoom = null;
    private float roomEntryTimer = 0f;

    /** Última escena conocida para entrar/salir por la puerta correcta. */
    private String currentSceneName = "ROOM";

    /**
     * Cuando Rupert se esconde, la enfermera NO desaparece.
     * Primero se detiene un momento y luego camina hasta la salida del cuarto.
     */
    private boolean leavingRoom = false;
    private String leavingRoomScene = null;
    private float leavingWaitTimer = 0f;

    public NurseEnemy(SimpleApplication app, Texture texture) {
        this(app, texture, 9, 2, 17, true);
    }

    /**
     * Constructor configurable para crear más de una enfermera.
     *
     * @param startTileX tile X donde inicia en el pasillo
     * @param minTileX límite izquierdo de su ruta
     * @param maxTileX límite derecho de su ruta
     * @param startsRight true si empieza mirando/caminando a la derecha
     */
    public NurseEnemy(SimpleApplication app, Texture texture,
                      float startTileX, float minTileX, float maxTileX,
                      boolean startsRight) {
        this.app = app;
        this.texture = texture;
        this.patrolStartX = startTileX * TILE;
        this.patrolMinX = minTileX * TILE;
        this.patrolMaxX = maxTileX * TILE;
        this.startDirection = startsRight ? Direction.RIGHT : Direction.LEFT;
        this.direction = this.startDirection;
        createSprite();
    }

    private void createSprite() {
        Quad quad = new Quad(SPRITE_SIZE, SPRITE_SIZE);
        sprite = new Geometry("NurseSprite", quad);

        Material mat = new Material(app.getAssetManager(), "Common/MatDefs/Misc/Unshaded.j3md");
        mat.setTexture("ColorMap", texture);
        mat.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);

        sprite.setQueueBucket(RenderQueue.Bucket.Transparent);
        sprite.setMaterial(mat);

        float offsetX = -((SPRITE_SIZE - HITBOX_W) / 2f);
        float offsetY = -((SPRITE_SIZE - HITBOX_H) / 2f - 5);
        sprite.setLocalTranslation(offsetX, offsetY, 0);

        enemyNode.attachChild(sprite);
        enemyNode.setLocalTranslation(patrolStartX, patrolY, 55);

        setFrame(getDirectionStartFrame(direction));
        hideVisual();
    }

    public Node getNode() {
        return enemyNode;
    }

    public boolean isChasing() {
        return chasing;
    }

    public boolean isVisible() {
        return visible;
    }

    /** Regresa true si la enfermera está saliendo de una habitación. */
    public boolean isLeavingRoom() {
        return leavingRoom;
    }

    /**
     * Se llama cuando Rupert entra o sale de una escena.
     *
     * Si Rupert entra al pasillo, la enfermera aparece donde iba, sin reiniciarse.
     * Si Rupert entra a una habitación mientras la enfermera lo perseguía,
     * la enfermera también entra a esa habitación.
     * Si Rupert entra a una habitación sin ser visto, la enfermera se oculta
     * pero sigue patrullando en segundo plano.
     */
    public void onSceneChanged(String sceneName) {
        String previousScene = currentSceneName;
        currentSceneName = sceneName;

        if (sceneName.equals("HALLWAY")) {
            waitingToEnterRoom = false;
            pendingRoom = null;

            // Si estaba persiguiendo dentro de un cuarto y Rupert salió,
            // la enfermera aparece en el pasillo por la puerta de ese cuarto.
            if (chasing && previousScene != null && !previousScene.equals("HALLWAY")) {
                enemyNode.setLocalTranslation(getHallwayDoorX(previousScene), patrolY, 55);
                placedInHallway = true;
            }

            showInHallway();
            return;
        }

        /*
         * Si Rupert entra a un cuarto SIN que la enfermera lo estuviera persiguiendo,
         * la enfermera NO entra. Se queda patrullando en el pasillo en segundo plano.
         */
        if (!chasing) {
            hideVisual();
            return;
        }

        /*
         * Si sí lo estaba persiguiendo, no aparece de golpe.
         * Se programa una entrada con retraso según la distancia a la puerta.
         */
        scheduleRoomEntry(sceneName);
    }

    /** Muestra a la enfermera en el pasillo, pero NO reinicia su ruta. */
    private void showInHallway() {
        active = true;
        visible = true;

        if (!placedInHallway) {
            enemyNode.setLocalTranslation(patrolStartX, patrolY, 55);
            direction = startDirection;
            placedInHallway = true;
        }

        enemyNode.setCullHint(Node.CullHint.Inherit);
    }

    /** Oculta a la enfermera visualmente, pero no borra su posición ni su ruta. */
    private void hideVisual() {
        visible = false;
        enemyNode.setCullHint(Node.CullHint.Always);
    }

    /**
     * Coloca a la enfermera en la entrada de la habitación cuando sigue a Rupert.
     */
    private void scheduleRoomEntry(String sceneName) {
        waitingToEnterRoom = true;
        pendingRoom = sceneName;

        float doorX = getHallwayDoorX(sceneName);
        float distanceToDoor = Math.abs(enemyNode.getLocalTranslation().x - doorX);

        // Tiempo aproximado para que se sienta natural.
        roomEntryTimer = Math.max(0.8f, distanceToDoor / CHASE_SPEED);

        // Mientras llega, no se ve dentro del cuarto.
        hideVisual();
    }

    private float getHallwayDoorX(String sceneName) {
        if (sceneName.equals("ROOM")) return 1 * TILE;
        if (sceneName.equals("NURSING")) return 5 * TILE;
        if (sceneName.equals("THERAPIST")) return 10 * TILE;
        if (sceneName.equals("DOCTORS")) return 15 * TILE;
        if (sceneName.equals("RECEPTION")) return 18 * TILE;
        return enemyNode.getLocalTranslation().x;
    }

    /**
     * Coloca a la enfermera dentro del cuarto, en la entrada correcta,
     * sin ponerla dentro de una pared.
     */
    private void enterRoom(String sceneName) {
        waitingToEnterRoom = false;
        pendingRoom = null;

        active = true;
        visible = true;
        enemyNode.setCullHint(Node.CullHint.Inherit);

        if (sceneName.equals("ROOM")) {
            // Misma posición donde aparece Rupert al entrar al cuarto desde el pasillo.
            enemyNode.setLocalTranslation(4 * TILE, -2 * TILE, 55);
            direction = Direction.LEFT;
        } else if (sceneName.equals("RECEPTION")) {
            // Misma posición donde aparece Rupert al entrar a recepción.
            enemyNode.setLocalTranslation(1 * TILE, -3 * TILE, 55);
            direction = Direction.RIGHT;
        } else if (sceneName.equals("NURSING")) {
            // Misma posición donde aparece Rupert al entrar a enfermería.
            enemyNode.setLocalTranslation(4 * TILE, -4 * TILE, 55);
            direction = Direction.BACK;
        } else if (sceneName.equals("THERAPIST")) {
            // Misma posición donde aparece Rupert al entrar al terapeuta.
            enemyNode.setLocalTranslation(3 * TILE, -4 * TILE, 55);
            direction = Direction.BACK;
        } else if (sceneName.equals("DOCTORS")) {
            // Misma posición donde aparece Rupert al entrar al consultorio de doctores.
            enemyNode.setLocalTranslation(3 * TILE, -4 * TILE, 55);
            direction = Direction.BACK;
        }
    }

    /**
     * Cuando Rupert se esconde debajo de una cama, la enfermera sale del cuarto
     * hacia el pasillo y sigue patrullando desde la puerta por donde entró.
     */
    private void leaveRoomToHallway(String sceneName) {
        float doorX = getHallwayDoorX(sceneName);

        enemyNode.setLocalTranslation(doorX, patrolY, 55);

        if (doorX <= patrolMinX) {
            direction = Direction.RIGHT;
        } else if (doorX >= patrolMaxX) {
            direction = Direction.LEFT;
        }

        waitingToEnterRoom = false;
        pendingRoom = null;
        placedInHallway = true;
        hideVisual();
    }

    /** Inicia la salida visible del cuarto cuando Rupert se esconde. */
    private void startLeavingRoom(String sceneName) {
        leavingRoom = true;
        leavingRoomScene = sceneName;
        leavingWaitTimer = 0.75f;
        chasing = false;
        waitingToEnterRoom = false;
        pendingRoom = null;
        visible = true;
        enemyNode.setCullHint(Node.CullHint.Inherit);
        updateAnimation(0, false);
    }

    /**
     * Hace que la enfermera camine hacia la salida del cuarto.
     * Cuando llega a la puerta, vuelve al pasillo y sigue su patrulla en segundo plano.
     */
    private void updateLeavingRoom(float tpf) {
        if (leavingWaitTimer > 0f) {
            leavingWaitTimer -= tpf;
            updateAnimation(tpf, false);
            return;
        }

        Vector3f pos = enemyNode.getLocalTranslation().clone();
        Vector3f target = getRoomExitPosition(leavingRoomScene);

        float dx = target.x - pos.x;
        float dy = target.y - pos.y;

        if (Math.abs(dx) <= 2f && Math.abs(dy) <= 2f) {
            leavingRoom = false;
            String finishedScene = leavingRoomScene;
            leavingRoomScene = null;
            leaveRoomToHallway(finishedScene);
            return;
        }

        if (Math.abs(dx) > Math.abs(dy)) {
            if (dx > 0) {
                direction = Direction.RIGHT;
                pos.x += Math.min(PATROL_SPEED * tpf, Math.abs(dx));
            } else {
                direction = Direction.LEFT;
                pos.x -= Math.min(PATROL_SPEED * tpf, Math.abs(dx));
            }
        } else {
            if (dy > 0) {
                direction = Direction.BACK;
                pos.y += Math.min(PATROL_SPEED * tpf, Math.abs(dy));
            } else {
                direction = Direction.FRONT;
                pos.y -= Math.min(PATROL_SPEED * tpf, Math.abs(dy));
            }
        }

        enemyNode.setLocalTranslation(pos);
        updateAnimation(tpf, true);
    }

    /** Posición de la puerta dentro de cada cuarto para salir de forma visible. */
    private Vector3f getRoomExitPosition(String sceneName) {
        if (sceneName == null) {
            return enemyNode.getLocalTranslation();
        }

        if (sceneName.equals("ROOM")) {
            return new Vector3f(5 * TILE, -3 * TILE, 55);
        }
        if (sceneName.equals("RECEPTION")) {
            return new Vector3f(0 * TILE, -3 * TILE, 55);
        }
        if (sceneName.equals("NURSING")) {
            return new Vector3f(4 * TILE, -5 * TILE, 55);
        }
        if (sceneName.equals("THERAPIST")) {
            return new Vector3f(3 * TILE, -5 * TILE, 55);
        }
        if (sceneName.equals("DOCTORS")) {
            return new Vector3f(3 * TILE, -5 * TILE, 55);
        }

        return enemyNode.getLocalTranslation();
    }

    /** Reinicia a la enfermera cuando se reinicia el juego. */
    public void resetEnemy() {
        active = true;
        visible = false;
        chasing = false;
        waitingToEnterRoom = false;
        pendingRoom = null;
        roomEntryTimer = 0f;
        leavingRoom = false;
        leavingRoomScene = null;
        leavingWaitTimer = 0f;
        placedInHallway = false;
        currentSceneName = "ROOM";
        direction = startDirection;
        enemyNode.setLocalTranslation(patrolStartX, patrolY, 55);
        hideVisual();
        setFrame(getDirectionStartFrame(direction));
    }

    /**
     * Patrulla de fondo cuando Rupert está en una habitación y la enfermera no lo persigue.
     * Así cuando regresas al pasillo no aparece reiniciada en el mismo punto.
     */
    public void updateBackgroundPatrol(float tpf) {
        if (chasing || leavingRoom) return;

        Vector3f pos = enemyNode.getLocalTranslation().clone();

        if (direction == Direction.RIGHT) {
            pos.x += PATROL_SPEED * tpf;
            if (pos.x >= patrolMaxX) {
                pos.x = patrolMaxX;
                direction = Direction.LEFT;
            }
        } else if (direction == Direction.LEFT) {
            pos.x -= PATROL_SPEED * tpf;
            if (pos.x <= patrolMinX) {
                pos.x = patrolMinX;
                direction = Direction.RIGHT;
            }
        }

        enemyNode.setLocalTranslation(pos);
        updateAnimation(tpf, true);
    }

    /**
     * Actualiza IA, movimiento, visión y animación.
     *
     * @param playerHidden true si Rupert está escondido debajo de una cama
     * @return true si atrapó a Rupert
     */
    public boolean update(float tpf, Vector3f playerPos, float playerW, float playerH,
                          int[][] collisionMap, boolean playerHidden, String sceneName) {
        if (!active) return false;

        if (leavingRoom) {
            updateLeavingRoom(tpf);
            return false;
        }

        /*
         * Si Rupert entró a un cuarto mientras la enfermera ya lo perseguía,
         * primero se espera un tiempo. Así no aparece instantáneamente.
         */
        if (waitingToEnterRoom) {
            roomEntryTimer -= tpf;

            if (playerHidden) {
                // Si se escondió antes de que la enfermera entrara, ella pierde el rastro
                // y continúa patrullando desde la puerta a la que iba llegando.
                leaveRoomToHallway(sceneName);
                chasing = false;
                return false;
            }

            if (roomEntryTimer <= 0f && pendingRoom != null) {
                enterRoom(pendingRoom);
            } else {
                updateAnimation(tpf, false);
                return false;
            }
        }

        if (!visible) return false;

        if (playerHidden) {
            // Si Rupert se esconde, la enfermera lo pierde, pero NO desaparece.
            // Se detiene un momento y camina hacia la salida del cuarto.
            if (!sceneName.equals("HALLWAY")) {
                startLeavingRoom(sceneName);
                return false;
            }

            chasing = false;
            updateAnimation(tpf, false);
            return false;
        }

        if (canSeePlayer(playerPos, playerW, playerH)) {
            chasing = true;
        }

        if (chasing) {
            chasePlayer(tpf, playerPos, collisionMap);
        } else {
            patrol(tpf, collisionMap);
        }

        updateAnimation(tpf, true);

        return touchesPlayer(playerPos, playerW, playerH);
    }

    private void patrol(float tpf, int[][] collisionMap) {
        Vector3f pos = enemyNode.getLocalTranslation().clone();

        if (direction == Direction.RIGHT) {
            pos.x += PATROL_SPEED * tpf;

            if (pos.x >= patrolMaxX || !canMoveTo(pos, collisionMap)) {
                direction = Direction.LEFT;
            } else {
                enemyNode.setLocalTranslation(pos);
            }
        } else {
            pos.x -= PATROL_SPEED * tpf;

            if (pos.x <= patrolMinX || !canMoveTo(pos, collisionMap)) {
                direction = Direction.RIGHT;
            } else {
                enemyNode.setLocalTranslation(pos);
            }
        }
    }

    private void chasePlayer(float tpf, Vector3f playerPos, int[][] collisionMap) {
        Vector3f pos = enemyNode.getLocalTranslation().clone();
        Vector3f next = pos.clone();

        float dx = playerPos.x - pos.x;
        float dy = playerPos.y - pos.y;

        if (Math.abs(dx) > Math.abs(dy)) {
            if (dx > 0) {
                direction = Direction.RIGHT;
                next.x += CHASE_SPEED * tpf;
            } else {
                direction = Direction.LEFT;
                next.x -= CHASE_SPEED * tpf;
            }
        } else {
            if (dy > 0) {
                direction = Direction.BACK;
                next.y += CHASE_SPEED * tpf;
            } else {
                direction = Direction.FRONT;
                next.y -= CHASE_SPEED * tpf;
            }
        }

        if (canMoveTo(next, collisionMap)) {
            enemyNode.setLocalTranslation(next);
        }
    }

    /**
     * Campo de visión rectangular.
     * Solo ve en la dirección en la que mira.
     */
    private boolean canSeePlayer(Vector3f playerPos, float playerW, float playerH) {
        Vector3f pos = enemyNode.getLocalTranslation();

        float nurseCenterX = pos.x + HITBOX_W / 2f;
        float nurseCenterY = -pos.y + HITBOX_H / 2f;

        float playerCenterX = playerPos.x + playerW / 2f;
        float playerCenterY = -playerPos.y + playerH / 2f;

        float dx = playerCenterX - nurseCenterX;
        float dy = playerCenterY - nurseCenterY;

        switch (direction) {
            case RIGHT:
                return dx > 0 && dx <= VISION_DISTANCE && Math.abs(dy) <= VISION_WIDTH;
            case LEFT:
                return dx < 0 && -dx <= VISION_DISTANCE && Math.abs(dy) <= VISION_WIDTH;
            case FRONT:
                return dy > 0 && dy <= VISION_DISTANCE && Math.abs(dx) <= VISION_WIDTH;
            case BACK:
                return dy < 0 && -dy <= VISION_DISTANCE && Math.abs(dx) <= VISION_WIDTH;
            default:
                return false;
        }
    }

    private boolean touchesPlayer(Vector3f playerPos, float playerW, float playerH) {
        Vector3f pos = enemyNode.getLocalTranslation();

        Rect nurseRect = new Rect(pos.x, -pos.y + 17, HITBOX_W, HITBOX_H);
        Rect playerRect = new Rect(playerPos.x, -playerPos.y + 17, playerW, playerH);

        return nurseRect.intersects(playerRect);
    }

    private boolean canMoveTo(Vector3f pos, int[][] collisionMap) {
        float left = pos.x;
        float right = pos.x + HITBOX_W;
        float top = -pos.y + 17;
        float bottom = -pos.y + HITBOX_H + 17;

        int leftTile = (int)(left / TILE);
        int rightTile = (int)(right / TILE);
        int topTile = (int)(top / TILE);
        int bottomTile = (int)(bottom / TILE);

        if (topTile < 0 || bottomTile >= collisionMap.length) return false;
        if (leftTile < 0 || rightTile >= collisionMap[0].length) return false;

        return collisionMap[topTile][leftTile] == 0 &&
               collisionMap[topTile][rightTile] == 0 &&
               collisionMap[bottomTile][leftTile] == 0 &&
               collisionMap[bottomTile][rightTile] == 0;
    }

    private void updateAnimation(float tpf, boolean moving) {
        int startFrame = getDirectionStartFrame(direction);

        if (moving) {
            animTimer += tpf;

            if (animTimer >= ANIM_SPEED) {
                animTimer = 0f;
                int localFrame = currentFrame - startFrame;

                if (localFrame < 0 || localFrame >= FRAMES_PER_DIRECTION) {
                    localFrame = 0;
                } else {
                    localFrame++;
                }

                if (localFrame >= FRAMES_PER_DIRECTION) {
                    localFrame = 0;
                }

                currentFrame = startFrame + localFrame;
            }
        } else {
            currentFrame = startFrame;
            animTimer = 0f;
        }

        setFrame(currentFrame);
    }

    private int getDirectionStartFrame(Direction dir) {
        switch (dir) {
            case FRONT:
                return 0;
            case RIGHT:
                return 6;
            case BACK:
                return 12;
            case LEFT:
                return 18;
            default:
                return 0;
        }
    }

    private void setFrame(int frameIndex) {
        float frameW = 1f / COLUMNS;
        float frameH = 1f / ROWS;

        int col = frameIndex % COLUMNS;
        int row = frameIndex / COLUMNS;

        float u0 = col * frameW;
        float u1 = u0 + frameW;
        float v0 = 1f - ((row + 1) * frameH);
        float v1 = v0 + frameH;

        VertexBuffer texBuffer = sprite.getMesh().getBuffer(VertexBuffer.Type.TexCoord);
        FloatBuffer data = BufferUtils.createFloatBuffer(
                u0, v0,
                u1, v0,
                u1, v1,
                u0, v1
        );

        if (texBuffer == null) {
            sprite.getMesh().setBuffer(VertexBuffer.Type.TexCoord, 2, data);
        } else {
            texBuffer.updateData(data);
        }

        sprite.getMesh().updateBound();
    }

    private enum Direction {
        FRONT,
        RIGHT,
        BACK,
        LEFT
    }
}
