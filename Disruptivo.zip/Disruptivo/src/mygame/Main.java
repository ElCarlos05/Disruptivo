package mygame;

/**
 * Clase Main por si tu proyecto usa Main.java como punto de inicio.
 */
public class Main {
    public static void main(String[] args) {
        HospitalGame app = new HospitalGame();
        app.start();
    }
}
