package mygame;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Aquí están TODAS las escenas del juego.
 *
 * Este archivo sirve para que HospitalGame.java no tenga miles de líneas de matrices.
 *
 * Cada escena tiene varias capas:
 * - floor: piso y paredes base
 * - wallDecor: decoración de pared
 * - furniture: muebles principales
 * - furnitureExtra: segunda capa de muebles
 * - objects: objetos
 * - extra: capa extra de objetos
 * - receptionTiles: capa especial para reception_room.png
 * - top: capa superior
 * - collision: colisión de muros, 1 bloquea y 0 deja pasar
 */
public class GameScenes {

    /**
     * Crea todas las escenas y las guarda en un Map.
     *
     * @param E valor para indicar espacio vacío
     * @return mapa con todas las escenas
     */
    public static Map<String, SceneLayers> createScenes(int E) {
        Map<String, SceneLayers> scenes = new HashMap<>();

        createRoom(scenes, E);
        createNursing(scenes, E);
        createDoctors(scenes, E);
        createTherapist(scenes, E);
        createReception(scenes, E);
        createHallway(scenes, E);

        return scenes;
    }

    private static void createRoom(Map<String, SceneLayers> scenes, int E) {
        int[][] roomFloor = {
                {4, 0, 0, 0, 0, 4},
                {4, 8, 8, 8, 8, 4},
                {4,12,12,12,12, 4},
                {4,12,12,12,12,12},
                {4,4,4,4,4,4}
        };

        int[][] roomWallDecor = {
                {25,E,E,E,E,24},
                {25,E,E,E,E,24},
                {25,E,E,E,E,14},
                {25,E,E,E,E,E},
                {E,0,0,0,0,0}
        };

        int[][] roomFurniture = {
                {E,E,E,E,E,E},
                {E,21,E,3,E,E},
                {E,25,E,7,E,E},
                {E,E,23,E,E,E},
                {E,E,E,E,E,E}
        };

        int[][] roomObjects = {
                {E,E,7,E,E,E},
                {E,E,15,E,32,E},
                {E,E,E,E,40,E},
                {E,E,E,E,E,E},
                {E,E,E,E,E,E}
        };

        int[][] roomFurnitureExtra = {
                {E,E,E,E,E,E},
                {E,E,E,E,E,E},
                {E,E,E,E,E,E},
                {E,E,19,E,E,E},
                {E,E,E,E,E,E}
        };

        int[][] roomExtra = {
                {E,E,E,E,E,E},
                {E,E,E,E,E,E},
                {E,E,E,E,56,E}, // 56 = llave de la enfermería
                {E,E,E,E,E,E},
                {E,E,E,E,E,E}
        };

        int[][] roomCollision = {
                {1,1,1,1,1,1},
                {1,1,1,1,1,1},
                {1,0,0,0,0,1},
                {1,0,0,0,0,0},
                {1,1,1,1,1,1}
        };

        scenes.put("ROOM", new SceneLayers(
                roomFloor, roomWallDecor, roomFurniture, roomFurnitureExtra,
                roomObjects, roomExtra, emptyLike(roomFloor, E),
                emptyLike(roomFloor, E), roomCollision
        ));
    }

    private static void createNursing(Map<String, SceneLayers> scenes, int E) {
        int[][] nursingFloor = {
                {4,0,0,0,0,0,0,4},
                {4,8,8,8,8,8,8,4},
                {4,12,12,12,12,12,12,4},
                {4,12,12,12,12,12,12,4},
                {4,12,12,12,12,12,12,4},
                {4,4,4,12,12,4,4,4}
        };

        int[][] nursingWallDecor = {
                {25,E,E,E,E,E,E,24},
                {25,E,E,E,E,E,E,24},
                {25,E,E,E,E,E,E,24},
                {25,E,E,E,E,E,E,24},
                {25,E,E,E,E,E,E,24},
                {E,0,11,E,E,10,0,E}
        };

        int[][] nursingFurniture = {
                {E,E,E,E,E,E,E,E},
                {E,35,E,22,E,28,29,E},
                {E,39,20,26,20,32,33,E},
                {E,E,E,E,E,E,E,E},
                {E,14,12,E,E,14,12,E},
                {E,E,E,E,E,E,E,E}
        };

        int[][] nursingObjects = {
                {E,E,E,E,E,E,E,E},
                {E,E,34,E,34,8,9,E},
                {E,E,42,E,42,E,E,E},
                {E,E,E,E,E,E,E,E},
                {E,E,E,E,E,E,E,E},
                {E,E,E,E,E,E,E,E}
        };

        int[][] nursingFurnitureExtra = emptyLike(nursingFloor, E);
        int[][] nursingExtra = emptyLike(nursingFloor, E);
        nursingExtra[0][3] = 4;
        nursingExtra[0][4] = 5;
        nursingExtra[1][3] = 12;
        nursingExtra[1][4] = 13;
        nursingExtra[0][6] = 7;
        nursingExtra[1][6] = 15;

        int[][] nursingCollision = {
                {1,1,1,1,1,1,1,1},
                {1,1,1,1,1,1,1,1},
                {1,0,0,0,0,0,0,1},
                {1,0,0,0,0,0,0,1},
                {1,0,0,0,0,0,0,1},
                {1,1,1,0,0,1,1,1}
        };

        scenes.put("NURSING", new SceneLayers(
                nursingFloor, nursingWallDecor, nursingFurniture, nursingFurnitureExtra,
                nursingObjects, nursingExtra, emptyLike(nursingFloor, E),
                emptyLike(nursingFloor, E), nursingCollision
        ));
    }

    private static void createDoctors(Map<String, SceneLayers> scenes, int E) {
        int[][] doctorsFloor = {
                {5,1,1,1,1,1,5},
                {5,9,9,9,9,9,5},
                {5,13,13,13,13,13,5},
                {5,13,13,13,13,13,5},
                {5,13,13,13,13,13,5},
                {5,5,5,13,5,5,5}
        };

        int[][] doctorsWallDecor = {
                {27,E,E,E,E,E,26},
                {27,E,E,E,E,E,26},
                {27,E,E,E,E,E,26},
                {27,E,E,E,E,E,26},
                {27,E,E,E,E,E,26},
                {E,1,19,E,18,1,E}
        };

        int[][] doctorsFurniture = {
                {E,E,E,E,E,18,E},
                {E,6,15,E,E,4,E},
                {E,30,31,E,E,8,E},
                {E,E,E,E,11,12,E},
                {E,E,E,E,E,E,E},
                {E,E,E,E,E,E,E}
        };

        int[][] doctorsObjects = {
                {E,7,E,23,6,E,E},
                {E,15,E,31,14,E,E},
                {E,33,E,39,35,E,E},
                {E,E,11,19,57,E,E},
                {E,E,E,E,E,E,E},
                {E,E,E,E,E,E,E}
        };

        int[][] doctorsFurnitureExtra = emptyLike(doctorsFloor, E);
        doctorsFurnitureExtra[2][1] = 0;
        doctorsFurnitureExtra[2][2] = 1;

        int[][] doctorsExtra = emptyLike(doctorsFloor, E);
        doctorsExtra[3][2] = 20;
        doctorsExtra[3][3] = 21;
        doctorsExtra[1][4] = 27;

        int[][] doctorsCollision = {
                {1,1,1,1,1,1,1},
                {1,1,1,1,1,1,1},
                {1,0,0,0,0,0,1},
                {1,0,0,0,0,0,1},
                {1,0,0,0,0,0,1},
                {1,1,1,0,1,1,1}
        };

        scenes.put("DOCTORS", new SceneLayers(
                doctorsFloor, doctorsWallDecor, doctorsFurniture, doctorsFurnitureExtra,
                doctorsObjects, doctorsExtra, emptyLike(doctorsFloor, E),
                emptyLike(doctorsFloor, E), doctorsCollision
        ));
    }

    private static void createTherapist(Map<String, SceneLayers> scenes, int E) {
        int[][] therapistFloor = {
                {4,0,0,0,0,4},
                {4,8,8,8,8,4},
                {4,12,12,12,12,4},
                {4,12,12,12,12,4},
                {4,12,12,12,12,4},
                {4,4,4,12,4,4}
        };

        int[][] therapistWallDecor = {
                {25,E,E,E,E,24},
                {25,E,E,E,E,24},
                {25,E,E,E,E,24},
                {25,E,E,E,E,24},
                {25,E,E,E,E,24},
                {E,0,11,E,10,E}
        };

        int[][] therapistFurniture = {
                {E,E,E,E,E,E},
                {E,E,13,13,13,E},
                {E,2,E,16,E,E},
                {E,E,E,E,E,E},
                {E,11,E,E,E,E},
                {E,E,E,E,E,E}
        };

        int[][] therapistObjects = {
                {E,E,48,49,50,E},
                {E,E,E,E,E,E},
                {E,43,E,E,E,E},
                {E,32,11,19,E,E},
                {E,40,E,E,E,E},
                {E,E,E,E,E,E}
        };

        int[][] therapistFurnitureExtra = emptyLike(therapistFloor, E);
        therapistFurnitureExtra[1][1] = 5;
        therapistFurnitureExtra[2][1] = 9;

        int[][] therapistExtra = emptyLike(therapistFloor, E);
        therapistExtra[3][2] = 20;
        therapistExtra[3][3] = 21;

        int[][] therapistCollision = {
                {1,1,1,1,1,1},
                {1,1,1,1,1,1},
                {1,0,0,0,0,1},
                {1,0,0,0,0,1},
                {1,0,0,0,0,1},
                {1,1,1,0,1,1}
        };

        scenes.put("THERAPIST", new SceneLayers(
                therapistFloor, therapistWallDecor, therapistFurniture, therapistFurnitureExtra,
                therapistObjects, therapistExtra, emptyLike(therapistFloor, E),
                emptyLike(therapistFloor, E), therapistCollision
        ));
    }

    private static void createReception(Map<String, SceneLayers> scenes, int E) {
        int[][] receptionFloor = {
                {4,0,0,0,0,0,0,4},
                {4,8,8,8,8,8,8,4},
                {4,12,12,12,12,12,12,4},
                {4,12,12,12,12,12,12,4},
                {12,12,12,12,12,12,12,4},
                {4,4,4,4,4,4,4,4}
        };

        int[][] receptionWallDecor = {
                {25,E,E,E,E,E,E,24},
                {25,E,E,E,E,E,E,24},
                {25,E,E,E,E,E,E,24},
                {15,E,E,E,E,E,E,24},
                {E,E,E,E,E,E,E,24},
                {0,0,0,0,0,0,0,E}
        };

        int[][] receptionFurniture = {
                {E,E,E,E,E,E,E,E},
                {E,E,5,E,E,E,E,E},
                {E,E,9,E,E,E,3,E},
                {E,E,E,E,E,E,7,E},
                {E,E,E,12,12,12,7,E},
                {E,E,E,E,E,E,E,E}
        };

        int[][] receptionFurnitureExtra = {
                {E,E,E,E,E,E,E,E},
                {E,E,E,E,E,E,E,E},
                {E,E,E,E,E,E,E,E},
                {E,E,E,E,E,E,3,E},
                {E,E,E,16,16,16,E,E},
                {E,E,E,E,E,E,E,E}
        };

        int[][] receptionObjects = {
                {E,E,4,5,E,E,6,E},
                {E,E,12,13,E,E,14,E},
                {E,E,41,44,E,E,E,E},
                {E,E,51,E,E,E,E,E},
                {E,E,E,E,E,E,E,E},
                {E,E,E,E,E,E,E,E}
        };

        int[][] receptionExtra = {
                {E,E,E,E,E,E,E,E},
                {E,E,E,32,E,E,27,E},
                {E,E,E,40,E,E,35,E},
                {E,E,E,E,E,E,E,E},
                {E,E,E,E,E,E,E,E},
                {E,E,E,E,E,E,E,E}
        };

        int[][] receptionTilesLayer = {
                {E,E,E,E,5,6,E,E},
                {E,E,E,3,13,14,E,E},
                {E,9,10,11,E,E,E,E},
                {E,17,18,19,E,E,E,E},
                {E,E,E,E,E,E,E,E},
                {E,E,E,E,E,E,E,E}
        };

        int[][] receptionCollision = {
                {1,1,1,1,1,1,1,1},
                {1,1,1,1,1,1,1,1},
                {1,0,0,0,0,0,0,1},
                {1,0,0,0,0,0,0,1},
                {0,0,0,0,0,0,0,1},
                {1,1,1,1,1,1,1,1}
        };

        scenes.put("RECEPTION", new SceneLayers(
                receptionFloor, receptionWallDecor, receptionFurniture, receptionFurnitureExtra,
                receptionObjects, receptionExtra, receptionTilesLayer,
                emptyLike(receptionFloor, E), receptionCollision
        ));
    }

    private static void createHallway(Map<String, SceneLayers> scenes, int E) {
        int[][] hallwayFloor = {
                {4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4},
                {4,8,8,8,8,3,8,8,8,8,3,8,8,8,8,3,8,8,8,4},
                {4,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,4},
                {4,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,4},
                {4,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,12,4},
                {4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4}
        };

        int[][] hallwayWallDecor = {
                {25,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,24},
                {25,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,24},
                {25,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,24},
                {25,7,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,16,24},
                {25,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,E,24},
                {E,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,E}
        };

        int[][] hallwayFurniture = emptyLike(hallwayFloor, E);

        int[][] hallwayObjects = emptyLike(hallwayFloor, E);
        hallwayObjects[1][4] = 27;
        hallwayObjects[1][6] = 27;
        hallwayObjects[1][9] = 27;
        hallwayObjects[1][11] = 27;
        hallwayObjects[1][14] = 27;
        hallwayObjects[1][16] = 27;
        hallwayObjects[2][4] = 35;
        hallwayObjects[2][6] = 35;
        hallwayObjects[2][9] = 35;
        hallwayObjects[2][11] = 35;
        hallwayObjects[2][14] = 35;
        hallwayObjects[2][16] = 35;
        hallwayObjects[0][7] = 4;
        hallwayObjects[0][8] = 5;
        hallwayObjects[1][7] = 12;
        hallwayObjects[1][8] = 13;
        hallwayObjects[0][13] = 6;
        hallwayObjects[1][13] = 14;

        int[][] hallwayFurnitureExtra = emptyLike(hallwayFloor, E);
        int[][] hallwayExtra = emptyLike(hallwayFloor, E);

        int[][] hallwayCollision = {
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
                {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
        };

        scenes.put("HALLWAY", new SceneLayers(
                hallwayFloor, hallwayWallDecor, hallwayFurniture, hallwayFurnitureExtra,
                hallwayObjects, hallwayExtra, emptyLike(hallwayFloor, E),
                emptyLike(hallwayFloor, E), hallwayCollision
        ));
    }

    /**
     * Crea una matriz vacía del mismo tamaño que otra matriz.
     */
    public static int[][] emptyLike(int[][] base, int E) {
        int[][] result = new int[base.length][base[0].length];

        for (int y = 0; y < result.length; y++) {
            Arrays.fill(result[y], E);
        }

        return result;
    }
}
