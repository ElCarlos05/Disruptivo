package mygame;

/**
 * Guarda todas las capas de una escena.
 *
 * Cada escena necesita las mismas capas para que HospitalGame pueda dibujarlas
 * sin importar si es ROOM, HALLWAY, RECEPTION, etc.
 */
public class SceneLayers {

    public int[][] floor;
    public int[][] wallDecor;
    public int[][] furniture;
    public int[][] furnitureExtra;
    public int[][] objects;
    public int[][] extra;
    public int[][] receptionTiles;
    public int[][] top;
    public int[][] collision;

    public SceneLayers(
            int[][] floor,
            int[][] wallDecor,
            int[][] furniture,
            int[][] furnitureExtra,
            int[][] objects,
            int[][] extra,
            int[][] receptionTiles,
            int[][] top,
            int[][] collision
    ) {
        this.floor = floor;
        this.wallDecor = wallDecor;
        this.furniture = furniture;
        this.furnitureExtra = furnitureExtra;
        this.objects = objects;
        this.extra = extra;
        this.receptionTiles = receptionTiles;
        this.top = top;
        this.collision = collision;
    }
}
