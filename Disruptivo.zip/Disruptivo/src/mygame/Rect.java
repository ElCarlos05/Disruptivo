package mygame;

/**
 * Rectángulo simple para colisiones manuales.
 *
 * Se usa principalmente para muebles.
 */
public class Rect {

    public float x;
    public float y;
    public float w;
    public float h;

    public Rect(float x, float y, float w, float h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

    /**
     * Revisa si este rectángulo toca otro rectángulo.
     */
    public boolean intersects(Rect other) {
        return other.x < x + w &&
               other.x + other.w > x &&
               other.y < y + h &&
               other.y + other.h > y;
    }
}
