package mygame;

import com.jme3.app.SimpleApplication;
import com.jme3.audio.AudioData;
import com.jme3.audio.AudioNode;
import com.jme3.input.KeyInput;
import com.jme3.input.MouseInput;
import com.jme3.input.controls.*;
import com.jme3.material.Material;
import com.jme3.material.RenderState;
import com.jme3.math.*;
import com.jme3.renderer.queue.RenderQueue;
import com.jme3.scene.*;
import com.jme3.scene.shape.Quad;
import com.jme3.texture.Texture;
import com.jme3.util.BufferUtils;
import java.nio.FloatBuffer;
import java.util.*;

/**
 * Clase principal del juego.
 *
 * Aquí se queda solamente lo que controla el juego en tiempo real:
 * - iniciar jMonkeyEngine
 * - cargar texturas
 * - dibujar el mapa actual
 * - mover a Rupert
 * - revisar puertas y salidas
 * - actualizar la cámara
 *
 * Las escenas están separadas en GameScenes.java.
 * Las colisiones de muebles están separadas en GameCollisions.java.
 */
public class HospitalGame extends SimpleApplication {

    private final float TILE = 32f;

    /** Tamaño de la caja invisible de colisión del personaje. */
    private final float PLAYER_WIDTH = 14f;
    private final float PLAYER_HEIGHT = 16f;

    /** Velocidad de movimiento. */
    private final float SPEED = 85f;

    /** Tamaño visual del sprite de Rupert. No afecta colisión. */
    private final float SPRITE_SIZE = 32f;

    /** Configuración del spritesheet de Rupert. */
    private final int RUPERT_COLUMNS = 24;
    private final int RUPERT_ROWS = 1;
    private final int FRAMES_PER_DIRECTION = 6;
    private final float ANIM_SPEED = 0.12f;

    /** Valor usado en matrices para indicar "no dibujar nada". */
    private final int E = -1;

    private Texture universales;
    private Texture furniture;
    private Texture objets;
    private Texture receptionTiles;
    private Texture rupertTexture;
    private Texture nurseTexture;
    private Texture patientBubbleTexture;
    private Texture prescriptionTexture;
    private Texture puzzleTexture;
    private Texture therapistPuzzleTexture;
    private Texture finalSceneTexture;

    /** Sonidos y música del juego. */
    private AudioNode hospitalTheme;
    private AudioNode receptionTheme;
    private AudioNode doorOpenSound;
    private AudioNode doorCloseSound;
    private AudioNode enemyVisionSound;
    private AudioNode getObjectSound;
    private AudioNode stepSound;
    private AudioNode hideSound;
    private float stepSoundTimer = 0f;
    private boolean receptionMusicPlaying = false;

    private final Node mapNode = new Node("Map");
    private final Node player = new Node("Player");
    private Geometry playerSprite;

    /** Enfermeras enemigas que patrullan el pasillo. */
    private final ArrayList<NurseEnemy> nurseEnemies = new ArrayList<>();

    private boolean left, right, up, down;
    private String scene = "ROOM";

    private float animTimer = 0f;
    private int currentFrame = 0;
    private Direction currentDirection = Direction.FRONT;

    private enum Direction {
        FRONT,
        RIGHT,
        BACK,
        LEFT
    }

    private int[][] currentFloor;
    private int[][] currentWallDecor;
    private int[][] currentFurniture;
    private int[][] currentFurnitureExtra;
    private int[][] currentObjects;
    private int[][] currentExtra;
    private int[][] currentReceptionTiles;
    private int[][] currentTop;
    private int[][] currentCollision;

    /** Colisiones manuales de muebles para la escena actual. */
    private final ArrayList<Rect> furnitureBlocks = new ArrayList<>();

    /** Zonas donde Rupert puede esconderse debajo de camas con E. */
    private final ArrayList<Rect> bedHideSpots = new ArrayList<>();

    /** Icono visual de tecla E para interacciones especiales. */
    private Geometry interactPrompt;

    /** Pantalla final del juego. */
    private Geometry finalScreen;
    private boolean finalScreenOpen = false;
    private final Rect receptionFinalDoorSpot = new Rect(4 * TILE, 0 * TILE, 2 * TILE, 3 * TILE);

    /** Mensaje que aparece arriba del paciente unos segundos. */
    private Geometry patientBubble;
    private boolean showingPatientBubble = false;
    private float patientBubbleTimer = 0f;

    /** Nota/receta en pantalla completa, se abre con E y se cierra con E. */
    private Geometry prescriptionScreen;
    private boolean prescriptionOpen = false;

    /** Indica si ya se leyó la nota/receta del objeto 9 de enfermería. */
    private boolean nursingPrescriptionRead = false;

    /** Puzzle de medicina verde. */
    private boolean puzzleOpen = false;
    private boolean puzzleSolved = false;
    private boolean hasGreenMedicine = false;
    private boolean hasTherapyKeySpawned = false;
    private boolean hasTherapyKey = false;
    private Node puzzleNode = new Node("MedicinePuzzle");
    private final ArrayList<Geometry> puzzleOptionGeometries = new ArrayList<>();
    private final ArrayList<Rect> puzzleOptionRects = new ArrayList<>();
    private final ArrayList<Integer> puzzleOptionTiles = new ArrayList<>();
    private final ArrayList<Integer> selectedPuzzleIndexes = new ArrayList<>();
    private Geometry puzzleResultGeometry;
    private float puzzleResultTimer = 0f;
    private boolean puzzleResultCorrect = false;

    /** Puzzle de terapia: seleccionar el cartel correcto para obtener la llave de doctores. */
    private boolean therapistPuzzleOpen = false;
    private boolean therapistPuzzleSolved = false;
    private boolean hasDoctorsKey = false;

    /** Llave 57 que se encuentra en doctores y permite abrir recepción. */
    private boolean hasReceptionKey = false;
    private float therapistPuzzleCloseTimer = 0f;
    private Node therapistPuzzleNode = new Node("TherapistPuzzle");
    private final ArrayList<Node> therapistPuzzlePosters = new ArrayList<>();
    private final ArrayList<Rect> therapistPuzzleRects = new ArrayList<>();

    /** Zona del objeto 49 de terapia. Abre el puzzle de carteles. */
    private final Rect therapistPosterSpot = new Rect(3 * TILE - 12, 0 * TILE, TILE + 24, TILE + 80);

    /** Zona de la nota/personaje en la cama superior izquierda de enfermería. */
    private final Rect nursingNoteSpot = new Rect(26, 38, 58, 58);

    /** Zona del objeto 8 de enfermería: abre el puzzle de medicinas.
     *  La zona está un poco más baja para que Rupert pueda interactuar parado debajo del mueble. */
    private final Rect nursingPrescriptionSpot = new Rect(5 * TILE - 12, 1 * TILE, TILE + 10, TILE + 90);

    /** Zona del objeto 9 de enfermería: abre la nota en pantalla completa.
     *  La zona está un poco más baja para que Rupert pueda interactuar parado debajo del mueble. */
    private final Rect nursingPuzzleSpot = new Rect(6 * TILE - 12, 1 * TILE, TILE + 10, TILE + 90);

    /** Lugar donde aparece la llave 59 después de ayudar al paciente. */
    private final int THERAPY_KEY_X = 1;
    private final int THERAPY_KEY_Y = 2;

    /** true cuando Rupert está escondido debajo de una cama. */
    private boolean hidingUnderBed = false;

    /** Llave que permite abrir la enfermería. */
    private boolean hasNursingKey = false;

    /** Todas las escenas del juego. */
    private Map<String, SceneLayers> scenes;

    public static void main(String[] args) {
        HospitalGame app = new HospitalGame();
        app.start();
    }

    @Override
    public void simpleInitApp() {
        flyCam.setEnabled(false);
        viewPort.setBackgroundColor(ColorRGBA.Black);

        universales = loadPixel("Tilesets/universales.png");
        furniture = loadPixel("Tilesets/furniture.png");
        objets = loadPixel("Tilesets/objets.png");
        receptionTiles = loadPixel("Tilesets/reception_room.png");
        rupertTexture = loadPixel("Textures/rupert.png");
        nurseTexture = loadPixel("Textures/nurse.png");
        patientBubbleTexture = loadPixel("Textures/patient_bubble.png");
        prescriptionTexture = loadPixel("Textures/prescription_2.png");
        puzzleTexture = loadPixel("Tilesets/nurset_puzzle.png");
        therapistPuzzleTexture = loadPixel("Tilesets/terapist_puzzle.png");
        finalSceneTexture = loadPixel("Textures/final_scene.png");

        createAudio();

        rootNode.attachChild(mapNode);

        scenes = GameScenes.createScenes(E);

        createPlayer();
        createInteractPrompt();
        createPatientBubble();
        createPrescriptionScreen();
        createPuzzleOverlay();
        createTherapistPuzzleOverlay();
        createFinalScreen();
        createNurseEnemy();
        initKeys();
        setupCamera();

        loadScene("ROOM", 2, 2);
    }

    /**
     * Carga una textura con filtro pixel art para que no se vea borrosa.
     */
    private Texture loadPixel(String path) {
        Texture tex = assetManager.loadTexture(path);
        tex.setMagFilter(Texture.MagFilter.Nearest);
        tex.setMinFilter(Texture.MinFilter.NearestNoMipMaps);
        return tex;
    }


    /**
     * Carga todos los sonidos del juego.
     *
     * Los archivos deben estar en:
     * assets/Sounds/
     */
    private void createAudio() {
        hospitalTheme = createMusic("Sounds/hospital_theme.ogg", 0.28f);
        receptionTheme = createMusic("Sounds/reception_theme.ogg", 0.32f);

        doorOpenSound = createSound("Sounds/door-open.ogg", 0.9f);
        doorCloseSound = createSound("Sounds/door-close.ogg", 0.9f);
        enemyVisionSound = createSound("Sounds/enemy_vision.ogg", 0.8f);
        getObjectSound = createSound("Sounds/get_object.ogg", 0.85f);
        stepSound = createSound("Sounds/step.ogg", 0.45f);
        hideSound = createSound("Sounds/safe.ogg", 0.75f);

        if (hospitalTheme != null) {
            hospitalTheme.play();
        }
    }

    /** Crea música en loop. */
    private AudioNode createMusic(String path, float volume) {
        AudioNode audio = new AudioNode(assetManager, path, AudioData.DataType.Buffer);
        audio.setLooping(true);
        audio.setPositional(false);
        audio.setVolume(volume);
        rootNode.attachChild(audio);
        return audio;
    }

    /** Crea un sonido corto para reproducir con playInstance(). */
    private AudioNode createSound(String path, float volume) {
        AudioNode audio = new AudioNode(assetManager, path, AudioData.DataType.Buffer);
        audio.setLooping(false);
        audio.setPositional(false);
        audio.setVolume(volume);
        rootNode.attachChild(audio);
        return audio;
    }

    /** Reproduce un sonido corto si ya fue cargado. */
    private void playSound(AudioNode audio) {
        if (audio != null) {
            audio.playInstance();
        }
    }

    /** Cambia la música dependiendo de la escena actual. */
    private void updateMusicForScene(String sceneName) {
        if (hospitalTheme == null || receptionTheme == null) {
            return;
        }

        if (sceneName.equals("RECEPTION")) {
            if (!receptionMusicPlaying) {
                hospitalTheme.stop();
                receptionTheme.play();
                receptionMusicPlaying = true;
            }
        } else {
            if (receptionMusicPlaying) {
                receptionTheme.stop();
                hospitalTheme.play();
                receptionMusicPlaying = false;
            }
        }
    }

    /**
     * Carga una escena y coloca al jugador en una posición por tile.
     *
     * @param name nombre de la escena
     * @param spawnX columna donde aparece Rupert
     * @param spawnY fila donde aparece Rupert
     */
    private void loadScene(String name, int spawnX, int spawnY) {
        String previousScene = scene;

        // Sonidos de puerta:
        // - al entrar desde el pasillo a una habitación suena abrir,
        // - al salir de una habitación al pasillo suena cerrar.
        if (previousScene != null && !previousScene.equals(name)) {
            if (previousScene.equals("HALLWAY") && !name.equals("HALLWAY")) {
                playSound(doorOpenSound);
            } else if (!previousScene.equals("HALLWAY") && name.equals("HALLWAY")) {
                playSound(doorCloseSound);
            }
        }

        scene = name;

        SceneLayers data = scenes.get(name);

        currentFloor = data.floor;
        currentWallDecor = data.wallDecor;
        currentFurniture = data.furniture;
        currentFurnitureExtra = data.furnitureExtra;
        currentObjects = data.objects;
        currentExtra = data.extra;
        currentReceptionTiles = data.receptionTiles;
        currentTop = data.top;
        currentCollision = data.collision;

        GameCollisions.setupFurnitureCollisions(name, furnitureBlocks);
        GameCollisions.setupBedHideSpots(name, bedHideSpots);

        hidingUnderBed = false;
        player.setCullHint(Node.CullHint.Inherit);
        hidePatientBubble();
        closePrescription();

        drawScene();

        player.setLocalTranslation(
                spawnX * TILE,
                -spawnY * TILE,
                50
        );

        updateCamera();
        updateMusicForScene(name);

        for (NurseEnemy nurse : nurseEnemies) {
            nurse.onSceneChanged(scene);
        }
    }

    /**
     * Dibuja las capas de la escena actual.
     * El orden importa: lo que va después se ve encima.
     */
    private void drawScene() {
        mapNode.detachAllChildren();

        drawUniversalLayer(currentFloor, 0);
        drawUniversalLayer(currentWallDecor, 6);
        drawFurnitureLayer(currentFurniture, 10);
        drawFurnitureLayer(currentFurnitureExtra, 8);
        drawObjectLayer(currentObjects, 15);
        drawObjectLayer(currentExtra, 20);
        drawReceptionLayer(currentReceptionTiles, 10);
        drawUniversalLayer(currentTop, 80);
    }

    private void drawUniversalLayer(int[][] layer, float z) {
        for (int y = 0; y < layer.length; y++) {
            for (int x = 0; x < layer[y].length; x++) {
                int tile = layer[y][x];
                if (tile == E) continue;
                drawUniversal(tile, x, y, z);
            }
        }
    }

    private void drawFurnitureLayer(int[][] layer, float z) {
        for (int y = 0; y < layer.length; y++) {
            for (int x = 0; x < layer[y].length; x++) {
                int tile = layer[y][x];
                if (tile == E) continue;
                drawFurniture(tile, x, y, z);
            }
        }
    }

    private void drawObjectLayer(int[][] layer, float z) {
        for (int y = 0; y < layer.length; y++) {
            for (int x = 0; x < layer[y].length; x++) {
                int tile = layer[y][x];
                if (tile == E) continue;
                drawObject(tile, x, y, z);
            }
        }
    }

    private void drawReceptionLayer(int[][] layer, float z) {
        for (int y = 0; y < layer.length; y++) {
            for (int x = 0; x < layer[y].length; x++) {
                int tile = layer[y][x];
                if (tile == E) continue;
                drawReception(tile, x, y, z);
            }
        }
    }

    private void drawUniversal(int tileNumber, int mapX, int mapY, float z) {
        int tileX = tileNumber % 4;
        int tileY = tileNumber / 4;
        createTile(universales, 4, 8, tileX, tileY, mapX * TILE, -mapY * TILE, z);
    }

    private void drawFurniture(int tileNumber, int mapX, int mapY, float z) {
        int tileX = tileNumber % 4;
        int tileY = tileNumber / 4;
        createTile(furniture, 4, 10, tileX, tileY, mapX * TILE, -mapY * TILE, z);
    }

    private void drawObject(int tileNumber, int mapX, int mapY, float z) {
        int tileX = tileNumber % 8;
        int tileY = tileNumber / 8;
        createTile(objets, 8, 8, tileX, tileY, mapX * TILE, -mapY * TILE, z);
    }

    private void drawReception(int tileNumber, int mapX, int mapY, float z) {
        int tileX = tileNumber % 8;
        int tileY = tileNumber / 8;
        createTile(receptionTiles, 8, 8, tileX, tileY, mapX * TILE, -mapY * TILE, z);
    }

    /**
     * Crea un tile individual a partir de un tileset.
     */
    private void createTile(Texture tex, int cols, int rows, int tileX, int tileY,
                            float x, float y, float z) {

        float tileW = 1f / cols;
        float tileH = 1f / rows;

        float u0 = tileX * tileW;
        float v0 = 1f - (tileY + 1) * tileH;
        float u1 = u0 + tileW;
        float v1 = v0 + tileH;

        Quad quad = new Quad(TILE, TILE);
        quad.clearBuffer(VertexBuffer.Type.TexCoord);

        quad.setBuffer(
                VertexBuffer.Type.TexCoord,
                2,
                BufferUtils.createFloatBuffer(
                        u0, v0,
                        u1, v0,
                        u1, v1,
                        u0, v1
                )
        );

        Geometry geo = new Geometry("tile", quad);

        Material mat = new Material(
                assetManager,
                "Common/MatDefs/Misc/Unshaded.j3md"
        );

        mat.setTexture("ColorMap", tex);
        mat.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);

        geo.setQueueBucket(RenderQueue.Bucket.Transparent);
        geo.setMaterial(mat);
        geo.setLocalTranslation(x, y, z);

        mapNode.attachChild(geo);
    }

    /**
     * Crea el personaje visual.
     * La colisión no depende del sprite, depende de PLAYER_WIDTH y PLAYER_HEIGHT.
     */
    private void createPlayer() {
        Quad quad = new Quad(SPRITE_SIZE, SPRITE_SIZE);
        playerSprite = new Geometry("RupertSprite", quad);

        Material mat = new Material(
                assetManager,
                "Common/MatDefs/Misc/Unshaded.j3md"
        );

        mat.setTexture("ColorMap", rupertTexture);
        mat.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);

        playerSprite.setQueueBucket(RenderQueue.Bucket.Transparent);
        playerSprite.setMaterial(mat);

        float visualOffsetX = -((SPRITE_SIZE - PLAYER_WIDTH) / 2f);
        float visualOffsetY = -((SPRITE_SIZE - PLAYER_HEIGHT) / 2f - 5);
        playerSprite.setLocalTranslation(visualOffsetX, visualOffsetY, 0);

        player.attachChild(playerSprite);
        rootNode.attachChild(player);

        setRupertFrame(0);
    }

    /**
     * Crea el icono de interacción con el tile 45 del tileset objets.png.
     *
     * Este icono aparece únicamente cuando Rupert está cerca de una
     * interacción especial, por ejemplo la nota/personaje de la enfermería.
     */
    private void createInteractPrompt() {
        interactPrompt = createTileGeometry(objets, 8, 8, 45, TILE);
        interactPrompt.setLocalTranslation(0, 0, 120);
        interactPrompt.setCullHint(Spatial.CullHint.Always);
        rootNode.attachChild(interactPrompt);
    }

    /**
     * Crea un tile individual como Geometry para usarlo de forma dinámica.
     * Se usa para el icono de interacción E sin tener que redibujar todo el mapa.
     */
    private Geometry createTileGeometry(Texture tex, int cols, int rows, int tileNumber, float size) {
        int tileX = tileNumber % cols;
        int tileY = tileNumber / cols;

        float tileW = 1f / cols;
        float tileH = 1f / rows;

        float u0 = tileX * tileW;
        float v0 = 1f - (tileY + 1) * tileH;
        float u1 = u0 + tileW;
        float v1 = v0 + tileH;

        Quad quad = new Quad(size, size);
        quad.clearBuffer(VertexBuffer.Type.TexCoord);
        quad.setBuffer(
                VertexBuffer.Type.TexCoord,
                2,
                BufferUtils.createFloatBuffer(
                        u0, v0,
                        u1, v0,
                        u1, v1,
                        u0, v1
                )
        );

        Geometry geo = new Geometry("InteractPrompt", quad);
        Material mat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        mat.setTexture("ColorMap", tex);
        mat.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);
        geo.setQueueBucket(RenderQueue.Bucket.Transparent);
        geo.setMaterial(mat);
        return geo;
    }

    /**
     * Crea el mensaje del paciente como imagen sobre el mapa.
     * Se mantiene oculto hasta que Rupert interactúa con el paciente.
     */
    private void createPatientBubble() {
        // Este mensaje va en el mundo, arriba del paciente, NO en GUI.
        // Por eso usamos createWorldImageGeometry().
        patientBubble = createWorldImageGeometry(patientBubbleTexture, 70, 70, "PatientBubble");

        // Posición aproximada arriba de la cama superior izquierda de enfermería.
        // Puedes mover estos números si lo quieres un poco más arriba/abajo.
        patientBubble.setLocalTranslation(48, -50, 200);
        patientBubble.setCullHint(Spatial.CullHint.Always);
        rootNode.attachChild(patientBubble);
    }

    /**
     * Crea la nota/receta en pantalla completa.
     * Se mantiene oculta hasta interactuar con el objeto 9 de enfermería.
     */
    private void createPrescriptionScreen() {
        prescriptionScreen = createImageGeometry(prescriptionTexture, 560, 560, "PrescriptionScreen");
        prescriptionScreen.setCullHint(Spatial.CullHint.Always);
        guiNode.attachChild(prescriptionScreen);
    }

    /**
     * Crea la interfaz del puzzle de medicina.
     * Está en guiNode para que se vea encima de toda la pantalla.
     */
    private void createPuzzleOverlay() {
        puzzleNode.setCullHint(Spatial.CullHint.Always);
        guiNode.attachChild(puzzleNode);
    }

    /** Crea la interfaz del puzzle de terapia. */
    private void createTherapistPuzzleOverlay() {
        therapistPuzzleNode.setCullHint(Spatial.CullHint.Always);
        guiNode.attachChild(therapistPuzzleNode);
    }

    /**
     * Crea la pantalla final. Se muestra cuando Rupert toca las puertas grandes
     * de recepción.
     */
    private void createFinalScreen() {

    float w = cam.getWidth();
    float h = cam.getHeight();

    finalScreen = createImageGeometry(
            finalSceneTexture,
            w,
            h,
            "FinalScene"
    );

    finalScreen.setCullHint(Spatial.CullHint.Always);
    guiNode.attachChild(finalScreen);
}

    /** Muestra la pantalla final y detiene el movimiento. */
    private void openFinalScreen() {
        finalScreenOpen = true;
        left = right = up = down = false;
        inputManager.setCursorVisible(false);

        if (finalScreen != null) {
            /*
             * Volvemos a ajustar el Quad aquí por si el usuario cambió
             * la resolución de la ventana antes de llegar al final.
             */
            float w = cam.getWidth();
            float h = cam.getHeight();

            finalScreen.setMesh(new Quad(w, h));
            finalScreen.setLocalTranslation(0, 0, 2000);
            finalScreen.setCullHint(Spatial.CullHint.Inherit);
        }
    }

    /** Oculta la pantalla final. */
    private void closeFinalScreen() {
        finalScreenOpen = false;
        if (finalScreen != null) {
            finalScreen.setCullHint(Spatial.CullHint.Always);
        }
    }

    /**
     * Crea una imagen completa como Geometry, útil para mensajes o notas.
     */
    private Geometry createImageGeometry(Texture tex, float width, float height, String name) {
        Quad quad = new Quad(width, height);
        Geometry geo = new Geometry(name, quad);
        Material mat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        mat.setTexture("ColorMap", tex);
        mat.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);

        // Para imágenes de pantalla completa, notas y overlays del puzzle.
        geo.setQueueBucket(RenderQueue.Bucket.Gui);
        geo.setMaterial(mat);
        return geo;
    }

    /**
     * Crea una imagen que vive dentro del mundo del juego.
     * Se usa para el globo del paciente, porque debe aparecer arriba de su cabeza.
     */
    private Geometry createWorldImageGeometry(Texture tex, float width, float height, String name) {
        Quad quad = new Quad(width, height);
        Geometry geo = new Geometry(name, quad);
        Material mat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        mat.setTexture("ColorMap", tex);
        mat.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);
        geo.setQueueBucket(RenderQueue.Bucket.Transparent);
        geo.setMaterial(mat);
        return geo;
    }

    /**
     * Crea un tile del puzzle como Geometry para la GUI.
     */
    private Geometry createPuzzleTileGeometry(int tileNumber, float size, String name) {
        int cols = 8;
        int rows = 8;
        int tileX = tileNumber % cols;
        int tileY = tileNumber / cols;

        float tileW = 1f / cols;
        float tileH = 1f / rows;

        float u0 = tileX * tileW;
        float v0 = 1f - (tileY + 1) * tileH;
        float u1 = u0 + tileW;
        float v1 = v0 + tileH;

        Quad quad = new Quad(size, size);
        quad.clearBuffer(VertexBuffer.Type.TexCoord);
        quad.setBuffer(
                VertexBuffer.Type.TexCoord,
                2,
                BufferUtils.createFloatBuffer(
                        u0, v0,
                        u1, v0,
                        u1, v1,
                        u0, v1
                )
        );

        Geometry geo = new Geometry(name, quad);
        Material mat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        mat.setTexture("ColorMap", puzzleTexture);
        mat.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);
        geo.setQueueBucket(RenderQueue.Bucket.Gui);
        geo.setMaterial(mat);
        return geo;
    }

    /** Crea un tile del puzzle de terapia como Geometry para la GUI. */
    private Geometry createTherapistPuzzleTileGeometry(int tileNumber, float size, String name) {
        int cols = 8;
        int rows = 8;
        int tileX = tileNumber % cols;
        int tileY = tileNumber / cols;

        float tileW = 1f / cols;
        float tileH = 1f / rows;

        float u0 = tileX * tileW;
        float v0 = 1f - (tileY + 1) * tileH;
        float u1 = u0 + tileW;
        float v1 = v0 + tileH;

        Quad quad = new Quad(size, size);
        quad.clearBuffer(VertexBuffer.Type.TexCoord);
        quad.setBuffer(VertexBuffer.Type.TexCoord, 2, BufferUtils.createFloatBuffer(
                u0, v0,
                u1, v0,
                u1, v1,
                u0, v1
        ));

        Geometry geo = new Geometry(name, quad);
        Material mat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        mat.setTexture("ColorMap", therapistPuzzleTexture);
        mat.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);
        geo.setQueueBucket(RenderQueue.Bucket.Gui);
        geo.setMaterial(mat);
        return geo;
    }

    /**
     * Crea la enfermera enemiga y la deja oculta hasta entrar al pasillo.
     */
    private void createNurseEnemy() {
        /*
         * Enfermera 1: ruta amplia por casi todo el pasillo.
         * Enfermera 2: ruta diferente, más hacia la derecha.
         */
        NurseEnemy nurseOne = new NurseEnemy(this, nurseTexture, 4, 2, 11, true);
        NurseEnemy nurseTwo = new NurseEnemy(this, nurseTexture, 16, 10, 18, false);

        nurseEnemies.add(nurseOne);
        nurseEnemies.add(nurseTwo);

        for (NurseEnemy nurse : nurseEnemies) {
            rootNode.attachChild(nurse.getNode());
            nurse.resetEnemy();
        }
    }

    private void updateRupertAnimation(float tpf, boolean moving) {
        int startFrame = getDirectionStartFrame(currentDirection);

        if (moving) {
            animTimer += tpf;

            if (animTimer >= ANIM_SPEED) {
                animTimer = 0f;

                int localFrame = currentFrame - startFrame;

                if (localFrame < 0 || localFrame >= FRAMES_PER_DIRECTION) {
                    localFrame = 0;
                } else {
                    localFrame++;
                }

                if (localFrame >= FRAMES_PER_DIRECTION) {
                    localFrame = 0;
                }

                currentFrame = startFrame + localFrame;
            }
        } else {
            currentFrame = startFrame;
            animTimer = 0f;
        }

        setRupertFrame(currentFrame);
    }

    private int getDirectionStartFrame(Direction direction) {
        switch (direction) {
            case FRONT:
                return 0;
            case RIGHT:
                return 6;
            case BACK:
                return 12;
            case LEFT:
                return 18;
            default:
                return 0;
        }
    }

    private void setRupertFrame(int frameIndex) {
        float frameW = 1f / RUPERT_COLUMNS;
        float frameH = 1f / RUPERT_ROWS;

        int col = frameIndex % RUPERT_COLUMNS;
        int row = frameIndex / RUPERT_COLUMNS;

        float u0 = col * frameW;
        float u1 = u0 + frameW;
        float v0 = 1f - ((row + 1) * frameH);
        float v1 = v0 + frameH;

        VertexBuffer texBuffer = playerSprite.getMesh().getBuffer(VertexBuffer.Type.TexCoord);
        FloatBuffer data = BufferUtils.createFloatBuffer(
                u0, v0,
                u1, v0,
                u1, v1,
                u0, v1
        );

        if (texBuffer == null) {
            playerSprite.getMesh().setBuffer(VertexBuffer.Type.TexCoord, 2, data);
        } else {
            texBuffer.updateData(data);
        }

        playerSprite.getMesh().updateBound();
    }

    private void setupCamera() {
        cam.setParallelProjection(true);

        float aspect = (float) cam.getWidth() / cam.getHeight();

        cam.setFrustum(
                -1000,
                1000,
                -145 * aspect,
                145 * aspect,
                145,
                -145
        );
    }

    private void updateCamera() {
        float mapWidth = currentFloor[0].length * TILE;
        float mapHeight = currentFloor.length * TILE;

        float camX = mapWidth / 2f;
        float camY = -(mapHeight / 2f);

        if (scene.equals("HALLWAY")) {
            Vector3f p = player.getLocalTranslation();

            camX = FastMath.clamp(
                    p.x,
                    5 * TILE,
                    mapWidth - 5 * TILE
            );
        }

        cam.setLocation(new Vector3f(camX, camY, 300));
        cam.lookAt(new Vector3f(camX, camY, 0), Vector3f.UNIT_Y);
    }

    /**
     * Revisa si Rupert puede moverse a una posición.
     * Primero revisa paredes y luego muebles.
     */
    private boolean canMoveTo(Vector3f pos) {

        float left = pos.x;
        float right = pos.x + PLAYER_WIDTH;

        float top = -pos.y + 17;
        float bottom = -pos.y + PLAYER_HEIGHT + 17;

        int leftTile = (int)(left / TILE);
        int rightTile = (int)(right / TILE);

        int topTile = (int)(top / TILE);
        int bottomTile = (int)(bottom / TILE);

        if (topTile < 0 || bottomTile >= currentCollision.length)
            return false;

        if (leftTile < 0 || rightTile >= currentCollision[0].length)
            return false;

        boolean canWalkOnMap =
                currentCollision[topTile][leftTile] == 0 &&
                currentCollision[topTile][rightTile] == 0 &&
                currentCollision[bottomTile][leftTile] == 0 &&
                currentCollision[bottomTile][rightTile] == 0;

        if (!canWalkOnMap) {
            return false;
        }

        return !collidesWithFurniture(pos);
    }

    /**
     * Revisa si el rectángulo de Rupert toca algún mueble.
     */
    private boolean collidesWithFurniture(Vector3f pos) {

        Rect playerRect = new Rect(
                pos.x,
                -pos.y + 17,
                PLAYER_WIDTH,
                PLAYER_HEIGHT
        );

        for (Rect block : furnitureBlocks) {
            if (playerRect.intersects(block)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Revisa si Rupert salió de una habitación hacia el pasillo.
     */
    private void checkExit() {
        if (scene.equals("HALLWAY")) return;

        Vector3f pos = player.getLocalTranslation();

        float feetX = pos.x + PLAYER_WIDTH / 2f;
        float feetY = -pos.y + PLAYER_HEIGHT;

        int x = (int) (feetX / TILE);
        int y = (int) (feetY / TILE);

        if (scene.equals("ROOM")) {
            if (x >= currentCollision[0].length - 1 && (y == 3 || y == 4)) {
                loadScene("HALLWAY", 1, 3);
            }

        } else if (scene.equals("NURSING")) {
            if (y >= currentCollision.length - 1 && x >= 3 && x <= 4) {
                loadScene("HALLWAY", 5, 2);
            }

        } else if (scene.equals("THERAPIST")) {
            if (y >= currentCollision.length - 1 && x >= 3 && x <= 4) {
                loadScene("HALLWAY", 10, 2);
            }

        } else if (scene.equals("DOCTORS")) {
            if (y >= currentCollision.length - 1 && x >= 3 && x <= 4) {
                loadScene("HALLWAY", 15, 2);
            }

        } else if (scene.equals("RECEPTION")) {
            if (x <= 0 && (y == 3 || y == 4)) {
                loadScene("HALLWAY", 18, 3);
            }
        }
    }

    /**
     * Revisa si Rupert tocó las puertas grandes de recepción.
     * Al tocarlas se muestra la pantalla final del juego.
     */
    private void checkFinalReceptionDoors() {
        if (finalScreenOpen || !scene.equals("RECEPTION")) {
            return;
        }

        if (getPlayerRect().intersects(receptionFinalDoorSpot)) {
            openFinalScreen();
        }
    }

    /**
     * Revisa si Rupert presionó E frente a una puerta del pasillo.
     */
    private void checkHallwayDoors() {
        if (!scene.equals("HALLWAY")) return;

        Vector3f pos = player.getLocalTranslation();

        float centerX = pos.x + PLAYER_WIDTH / 2f;
        float centerY = -pos.y + PLAYER_HEIGHT / 2f + 17;

        int x = (int)(centerX / TILE);
        int y = (int)(centerY / TILE);

        if (y < 0 || y >= currentFloor.length) return;
        if (x < 0 || x >= currentFloor[0].length) return;

        if (currentWallDecor[y][x] == 7 || currentWallDecor[y][x] == 16) {
            if (x <= 3) {
                loadScene("ROOM",4, 2);
            } else {
                // La recepción está bloqueada hasta recoger la llave 57 en doctores.
                if (!hasReceptionKey) {
                    System.out.println("La recepción está cerrada. Necesitas la llave 57.");
                    return;
                }
                loadScene("RECEPTION", 1, 3);
            }
            return;
        }

        if (!isNearFloorDoor3(x, y)) {
            return;
        }

        if (x <= 6) {
            if (!hasNursingKey) {
                System.out.println("La puerta de enfermería está cerrada. Necesitas la llave.");
                return;
            }
            loadScene("NURSING", 4, 4);
        } else if (x <= 13) {
            if (!hasTherapyKey) {
                System.out.println("La puerta de terapia está cerrada. Necesitas la llave 59.");
                return;
            }
            loadScene("THERAPIST", 3, 4);
        } else {
            if (!hasDoctorsKey) {
                System.out.println("La puerta de doctores está cerrada. Necesitas la llave pequeña.");
                return;
            }
            loadScene("DOCTORS", 3, 4);
        }
    }

    private boolean isNearFloorDoor3(int x, int y) {
        for (int dy = -1; dy <= 1; dy++) {
            int ty = y + dy;

            if (ty < 0 || ty >= currentFloor.length) continue;

            if (currentFloor[ty][x] == 3) {
                return true;
            }
        }

        return false;
    }

    /**
     * Reinicia la partida cuando la enfermera atrapa a Rupert.
     * Puedes cambiar el cuarto y spawn inicial aquí.
     */
    private void restartGame() {
        left = false;
        right = false;
        up = false;
        down = false;
        currentDirection = Direction.FRONT;
        currentFrame = 0;
        setRupertFrame(currentFrame);
        hidingUnderBed = false;
        hasNursingKey = false;
        hasGreenMedicine = false;
        hasTherapyKeySpawned = false;
        hasTherapyKey = false;
        hasDoctorsKey = false;
        hasReceptionKey = false;
        nursingPrescriptionRead = false;
        puzzleSolved = false;
        therapistPuzzleSolved = false;
        closePuzzle();
        closeTherapistPuzzle();
        closePrescription();
        hidePatientBubble();
        scenes = GameScenes.createScenes(E);
        player.setCullHint(Node.CullHint.Inherit);
        for (NurseEnemy nurse : nurseEnemies) {
            nurse.resetEnemy();
        }
        loadScene("ROOM", 2, 2);
    }


    /**
     * Maneja la tecla E.
     *
     * Prioridad:
     * 1. Si está escondido, sale de debajo de la cama.
     * 2. Si está tocando una zona de cama, se esconde.
     * 3. Si está en el pasillo, intenta entrar por una puerta.
     */
    private void handleInteract() {
        if (finalScreenOpen) {
            return;
        }

        if (prescriptionOpen) {
            closePrescription();
            return;
        }

        if (puzzleOpen) {
            return;
        }

        if (therapistPuzzleOpen) {
            if (therapistPuzzleSolved) {
                closeTherapistPuzzle();
            }
            return;
        }

        if (hidingUnderBed) {
            hidingUnderBed = false;
            player.setCullHint(Node.CullHint.Inherit);
            playSound(hideSound);
            return;
        }

        if (isNearTherapyKey()) {
            collectTherapyKey();
            return;
        }

        if (isNearReceptionKey()) {
            collectReceptionKey();
            return;
        }

        if (isNearTherapistPosterPuzzle()) {
            if (!therapistPuzzleSolved) {
                openTherapistPuzzle();
            }
            return;
        }

        // Objeto 9 de enfermería: abre la nota en pantalla completa.
        if (isNearNursingObject9()) {
            openPrescription();
            nursingPrescriptionRead = true;
            return;
        }

        // Objeto 8 de enfermería: abre el puzzle de medicinas.
        if (isNearNursingPrescription()) {
            if (!puzzleSolved) {
                openPuzzle();
            }
            return;
        }

        if (isNearNursingNote()) {
            if (hasGreenMedicine && !hasTherapyKeySpawned) {
                giveGreenMedicineToPatient();
            } else {
                readNursingNote();
            }
            return;
        }

        if (isNearNursingKey()) {
            collectNursingKey();
            return;
        }

        if (canHideUnderBed()) {
            hidingUnderBed = true;
            player.setCullHint(Node.CullHint.Always);
            playSound(hideSound);
            left = false;
            right = false;
            up = false;
            down = false;
            return;
        }

        checkHallwayDoors();
    }

    /**
     * Crea el rectángulo de interacción del jugador.
     * Este rectángulo representa la caja invisible de Rupert.
     */
    private Rect getPlayerRect() {
        return new Rect(
                player.getLocalTranslation().x,
                -player.getLocalTranslation().y + 17,
                PLAYER_WIDTH,
                PLAYER_HEIGHT
        );
    }

    /**
     * Regresa la cama cercana donde Rupert puede esconderse.
     * Si no está tocando ninguna cama válida, regresa null.
     */
    private Rect getNearBedHideSpot() {
        Rect playerRect = getPlayerRect();

        for (Rect bed : bedHideSpots) {
            if (playerRect.intersects(bed)) {
                return bed;
            }
        }

        return null;
    }

    /**
     * Revisa si Rupert está tocando una zona válida para esconderse.
     */
    private boolean canHideUnderBed() {
        return getNearBedHideSpot() != null;
    }

    /**
     * Revisa si Rupert está cerca de la interacción de nota/personaje
     * ubicada en la cama superior izquierda de enfermería.
     */
    private boolean isNearNursingNote() {
        if (!scene.equals("NURSING")) {
            return false;
        }

        return getPlayerRect().intersects(nursingNoteSpot);
    }

    /**
     * Revisa si Rupert está cerca de la llave de enfermería.
     * La llave está en ROOM, capa extra, tile 56, posición columna 4 fila 2.
     */
    private boolean isNearNursingKey() {
        if (!scene.equals("ROOM") || hasNursingKey) {
            return false;
        }

        if (currentExtra == null || currentExtra.length <= 2 || currentExtra[2].length <= 4) {
            return false;
        }

        if (currentExtra[2][4] != 56) {
            return false;
        }

        Rect keySpot = new Rect(4 * TILE, 2 * TILE, TILE, TILE);
        return getPlayerRect().intersects(keySpot);
    }

    /**
     * Revisa si Rupert está cerca del objeto 9 de enfermería.
     * Este objeto abre la nota en pantalla completa.
     */
    private boolean isNearNursingObject9() {
        if (!scene.equals("NURSING")) {
            return false;
        }

        return getPlayerRect().intersects(nursingPuzzleSpot);
    }

    /**
     * Revisa si Rupert está cerca del objeto 8 de enfermería,
     * donde se abre el puzzle de medicinas.
     */
    private boolean isNearNursingPrescription() {
        if (!scene.equals("NURSING") || puzzleSolved) {
            return false;
        }

        return getPlayerRect().intersects(nursingPrescriptionSpot);
    }

    /**
     * Revisa si Rupert está cerca del objeto 8 de enfermería,
     * donde se abre el puzzle de medicinas.
     */
    private boolean isNearNursingPuzzle() {
        if (!scene.equals("NURSING") || puzzleSolved) {
            return false;
        }

        return getPlayerRect().intersects(nursingPrescriptionSpot);
    }

    /**
     * Revisa si Rupert está cerca de la llave 57 en la sala de doctores.
     * Esa llave desbloquea la recepción.
     */
    private boolean isNearReceptionKey() {
        if (!scene.equals("DOCTORS") || hasReceptionKey) {
            return false;
        }

        // En GameScenes.java la llave 57 está en doctorsObjects[3][4].
        if (currentObjects == null || currentObjects.length <= 3 || currentObjects[3].length <= 4) {
            return false;
        }

        if (currentObjects[3][4] != 57) {
            return false;
        }

        Rect keySpot = new Rect(4 * TILE, 3 * TILE, TILE, TILE);
        return getPlayerRect().intersects(keySpot);
    }

    /** Revisa si Rupert está cerca del objeto 49 de terapia. */
    private boolean isNearTherapistPosterPuzzle() {
        if (!scene.equals("THERAPIST") || therapistPuzzleSolved) {
            return false;
        }

        return getPlayerRect().intersects(therapistPosterSpot);
    }

    /**
     * Revisa si Rupert está cerca de la llave 59 para terapia.
     */
    private boolean isNearTherapyKey() {
        if (!scene.equals("NURSING") || !hasTherapyKeySpawned || hasTherapyKey) {
            return false;
        }

        if (currentExtra == null || currentExtra.length <= THERAPY_KEY_Y
                || currentExtra[THERAPY_KEY_Y].length <= THERAPY_KEY_X) {
            return false;
        }

        if (currentExtra[THERAPY_KEY_Y][THERAPY_KEY_X] != 59) {
            return false;
        }

        Rect keySpot = new Rect(THERAPY_KEY_X * TILE, THERAPY_KEY_Y * TILE, TILE, TILE);
        return getPlayerRect().intersects(keySpot);
    }

    /**
     * Recoge la llave 59 que desbloquea la habitación de terapia.
     */
    private void collectTherapyKey() {
        hasTherapyKey = true;

        if (currentExtra != null && currentExtra.length > THERAPY_KEY_Y
                && currentExtra[THERAPY_KEY_Y].length > THERAPY_KEY_X) {
            currentExtra[THERAPY_KEY_Y][THERAPY_KEY_X] = E;
        }

        drawScene();
        playSound(getObjectSound);
        System.out.println("Llave de terapia obtenida.");
    }

    /**
     * Recoge la llave 57 de la sala de doctores.
     * Al recogerla, la borramos del mapa y ya se puede entrar a recepción.
     */
    private void collectReceptionKey() {
        hasReceptionKey = true;

        if (currentObjects != null && currentObjects.length > 3 && currentObjects[3].length > 4) {
            currentObjects[3][4] = E;
        }

        drawScene();
        playSound(getObjectSound);
        System.out.println("Llave de recepción obtenida.");
    }

    /**
     * Entrega la medicina verde al paciente y hace aparecer la llave 59 debajo de la cama.
     */
    private void giveGreenMedicineToPatient() {
        hasGreenMedicine = false;
        hasTherapyKeySpawned = true;

        if (currentExtra != null && currentExtra.length > THERAPY_KEY_Y
                && currentExtra[THERAPY_KEY_Y].length > THERAPY_KEY_X) {
            currentExtra[THERAPY_KEY_Y][THERAPY_KEY_X] = 59;
        }

        drawScene();
        playSound(getObjectSound);
        showPatientBubble();
        System.out.println("El paciente dejó una llave debajo de la cama.");
    }

    /**
     * Recoge la llave de enfermería y la borra del mapa.
     */
    private void collectNursingKey() {
        hasNursingKey = true;

        if (currentExtra != null && currentExtra.length > 2 && currentExtra[2].length > 4) {
            currentExtra[2][4] = E;
        }

        drawScene();
        playSound(getObjectSound);
        System.out.println("Llave de enfermería obtenida.");
    }

    /**
     * Busca una puerta cercana del pasillo que use la tecla E.
     * Regresa la posición donde debe aparecer el icono E.
     */
    private Vector3f getHallwayDoorPromptPosition() {
        if (!scene.equals("HALLWAY")) {
            return null;
        }

        Vector3f pos = player.getLocalTranslation();

        float centerX = pos.x + PLAYER_WIDTH / 2f;
        float centerY = -pos.y + PLAYER_HEIGHT / 2f + 17;

        int x = (int)(centerX / TILE);
        int y = (int)(centerY / TILE);

        if (y < 0 || y >= currentFloor.length) return null;
        if (x < 0 || x >= currentFloor[0].length) return null;

        // Puertas laterales exactas: cuarto de Rupert y recepción.
        if (currentWallDecor[y][x] == 7 || currentWallDecor[y][x] == 16) {
            return new Vector3f(x * TILE, -y * TILE + 16, 120);
        }

        // Puertas superiores marcadas con tile 3.
        for (int dy = -1; dy <= 1; dy++) {
            int ty = y + dy;

            if (ty < 0 || ty >= currentFloor.length) continue;

            if (currentFloor[ty][x] == 3) {
                return new Vector3f(x * TILE, -ty * TILE + 16, 120);
            }
        }

        return null;
    }

    /**
     * Muestra u oculta el icono E según la cercanía a cualquier interacción.
     *
     * El icono E aparece en:
     * - nota/personaje de enfermería,
     * - camas donde Rupert puede esconderse,
     * - puertas del pasillo que usan E.
     */
    private void updateInteractionPrompt() {
        if (interactPrompt == null) {
            return;
        }

        if (puzzleOpen || prescriptionOpen || therapistPuzzleOpen) {
            interactPrompt.setCullHint(Spatial.CullHint.Always);
            return;
        }

        Vector3f promptPos = null;

        if (hidingUnderBed) {
            // Si Rupert está escondido, también se muestra E para indicar que puede salir.
            Vector3f pos = player.getLocalTranslation();
            promptPos = new Vector3f(pos.x, pos.y + 24, 120);
        } else if (isNearNursingNote()) {
            // Icono sobre la nota/personaje de la enfermería.
            promptPos = new Vector3f(2 * TILE, -1 * TILE, 120);
        } else if (isNearNursingKey()) {
            // Icono sobre la llave de enfermería.
            promptPos = new Vector3f(4 * TILE, -2 * TILE + 20, 120);
        } else if (isNearReceptionKey()) {
            // Icono sobre la llave 57 de doctores.
            promptPos = new Vector3f(4 * TILE, -3 * TILE + 20, 120);
        } else if (isNearTherapistPosterPuzzle()) {
            // Icono sobre el objeto 49 de terapia.
            promptPos = new Vector3f(3 * TILE, 12, 120);
        } else if (isNearTherapyKey()) {
            // Icono sobre la llave 59 de terapia.
            promptPos = new Vector3f(THERAPY_KEY_X * TILE, -THERAPY_KEY_Y * TILE + 20, 120);
        } else if (isNearNursingObject9()) {
            // Icono sobre el objeto 9: abre la nota en pantalla completa.
            promptPos = new Vector3f(6 * TILE, -1 * TILE + 6, 120);
        } else if (isNearNursingPrescription()) {
            // Icono sobre el objeto 8: abre el puzzle de medicinas.
            promptPos = new Vector3f(5 * TILE, -1 * TILE + 6, 120);
        } else {
            Rect bed = getNearBedHideSpot();

            if (bed != null) {
                // Icono sobre la cama donde se puede esconder.
                promptPos = new Vector3f(
                        bed.x + bed.w / 2f - TILE / 2f,
                        -bed.y + 20,
                        120
                );
            } else {
                // Icono sobre puertas del pasillo.
                promptPos = getHallwayDoorPromptPosition();
            }
        }

        if (promptPos != null) {
            interactPrompt.setLocalTranslation(promptPos);
            interactPrompt.setCullHint(Spatial.CullHint.Inherit);
        } else {
            interactPrompt.setCullHint(Spatial.CullHint.Always);
        }
    }

    /**
     * Interacción de la nota/personaje de enfermería.
     * Por ahora se imprime en consola; después puedes cambiarlo por un texto en pantalla.
     */
    private void readNursingNote() {
        showPatientBubble();
        System.out.println("Paciente: Si me ayudas, puede que obtengas algo a cambio...");
    }

    /** Muestra el globo del paciente durante unos segundos. */
    private void showPatientBubble() {
        showingPatientBubble = true;
        patientBubbleTimer = 4f;
        if (patientBubble != null) {
            patientBubble.setCullHint(Spatial.CullHint.Inherit);
        }
    }

    /** Oculta el globo del paciente. */
    private void hidePatientBubble() {
        showingPatientBubble = false;
        patientBubbleTimer = 0f;
        if (patientBubble != null) {
            patientBubble.setCullHint(Spatial.CullHint.Always);
        }
    }

    /** Actualiza el tiempo del globo del paciente. */
    private void updatePatientBubble(float tpf) {
        if (!showingPatientBubble) return;

        patientBubbleTimer -= tpf;
        if (patientBubbleTimer <= 0f) {
            hidePatientBubble();
        }
    }

    /** Abre la receta en pantalla completa. */
    private void openPrescription() {
        prescriptionOpen = true;
        left = right = up = down = false;

        float w = cam.getWidth();
        float h = cam.getHeight();

        if (prescriptionScreen != null) {
            // La imagen conserva proporción cuadrada y se centra en la pantalla.
            prescriptionScreen.setLocalTranslation(
                    w / 2f - 280,
                    h / 2f - 280,
                    1000
            );
            prescriptionScreen.setCullHint(Spatial.CullHint.Inherit);
        }
    }

    /** Cierra la receta en pantalla completa. */
    private void closePrescription() {
        prescriptionOpen = false;
        if (prescriptionScreen != null) {
            prescriptionScreen.setCullHint(Spatial.CullHint.Always);
        }
    }

    /** Abre el puzzle de las medicinas y desbloquea el mouse. */
    private void openPuzzle() {
        puzzleOpen = true;
        puzzleResultTimer = 0f;
        puzzleResultCorrect = false;
        selectedPuzzleIndexes.clear();
        puzzleNode.detachAllChildren();
        puzzleOptionGeometries.clear();
        puzzleOptionRects.clear();
        puzzleOptionTiles.clear();

        inputManager.setCursorVisible(true);
        left = right = up = down = false;

        float w = cam.getWidth();
        float h = cam.getHeight();

        Quad bgQuad = new Quad(w, h);
        Geometry bg = new Geometry("PuzzleGrayBackground", bgQuad);
        Material bgMat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        bgMat.setColor("Color", new ColorRGBA(0.25f, 0.25f, 0.25f, 0.90f));
        bgMat.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);
        bg.setQueueBucket(RenderQueue.Bucket.Gui);
        bg.setMaterial(bgMat);
        bg.setLocalTranslation(0, 0, 0);
        puzzleNode.attachChild(bg);

        addPuzzleOption(2, w / 2f - 150, h / 2f + 45);
        addPuzzleOption(3, w / 2f - 48,  h / 2f + 45);
        addPuzzleOption(4, w / 2f + 54,  h / 2f + 45);
        addPuzzleDecoration(5, w / 2f - 48, h / 2f - 85);

        puzzleNode.setCullHint(Spatial.CullHint.Inherit);
    }

    /** Agrega un frasco seleccionable al puzzle. */
    private void addPuzzleOption(int tile, float x, float y) {
        Geometry geo = createPuzzleTileGeometry(tile, 96, "Potion" + tile);
        geo.setLocalTranslation(x, y, 10);
        puzzleNode.attachChild(geo);

        puzzleOptionGeometries.add(geo);
        puzzleOptionRects.add(new Rect(x, y, 96, 96));
        puzzleOptionTiles.add(tile);
    }

    /** Agrega un tile decorativo no seleccionable al puzzle. */
    private void addPuzzleDecoration(int tile, float x, float y) {
        Geometry geo = createPuzzleTileGeometry(tile, 96, "PuzzleDecoration" + tile);
        geo.setLocalTranslation(x, y, 10);
        puzzleNode.attachChild(geo);
    }

    /** Cierra el puzzle y bloquea el mouse de nuevo. */
    private void closePuzzle() {
        puzzleOpen = false;
        puzzleResultTimer = 0f;
        selectedPuzzleIndexes.clear();
        if (puzzleNode != null) {
            puzzleNode.detachAllChildren();
            puzzleNode.setCullHint(Spatial.CullHint.Always);
        }
        if (inputManager != null) {
            inputManager.setCursorVisible(false);
        }
    }

    /** Selecciona un frasco del puzzle con el mouse. */
    private void handlePuzzleClick() {
        if (!puzzleOpen || puzzleResultTimer > 0f) return;

        Vector2f cursor = inputManager.getCursorPosition();

        for (int i = 0; i < puzzleOptionRects.size(); i++) {
            Rect r = puzzleOptionRects.get(i);
            if (cursor.x >= r.x && cursor.x <= r.x + r.w
                    && cursor.y >= r.y && cursor.y <= r.y + r.h) {
                togglePuzzleSelection(i);
                return;
            }
        }
    }

    /** Sube o baja un frasco para marcarlo como seleccionado. */
    private void togglePuzzleSelection(int index) {
        Geometry geo = puzzleOptionGeometries.get(index);
        Vector3f pos = geo.getLocalTranslation();

        if (selectedPuzzleIndexes.contains(index)) {
            selectedPuzzleIndexes.remove(Integer.valueOf(index));
            geo.setLocalTranslation(pos.x, pos.y - 14, pos.z);
            return;
        }

        if (selectedPuzzleIndexes.size() >= 2) {
            return;
        }

        selectedPuzzleIndexes.add(index);
        geo.setLocalTranslation(pos.x, pos.y + 14, pos.z);
    }

    /** Confirma la combinación con Enter. */
    private void confirmPuzzleCombination() {
        if (!puzzleOpen || selectedPuzzleIndexes.size() != 2 || puzzleResultTimer > 0f) {
            return;
        }

        int a = puzzleOptionTiles.get(selectedPuzzleIndexes.get(0));
        int b = puzzleOptionTiles.get(selectedPuzzleIndexes.get(1));

        boolean correct = (a == 2 && b == 3) || (a == 3 && b == 2);
        showPuzzleResult(correct ? 12 : 6, correct);
    }

    /** Muestra el resultado de la mezcla. */
    private void showPuzzleResult(int resultTile, boolean correct) {
        if (puzzleResultGeometry != null) {
            puzzleResultGeometry.removeFromParent();
        }

        float w = cam.getWidth();
        float h = cam.getHeight();
        puzzleResultGeometry = createPuzzleTileGeometry(resultTile, 104, "PuzzleResult");
        puzzleResultGeometry.setLocalTranslation(w / 2f - 52, h / 2f - 190, 30);
        puzzleNode.attachChild(puzzleResultGeometry);

        puzzleResultCorrect = correct;
        puzzleResultTimer = correct ? 1.5f : 1.0f;
    }

    /** Actualiza el puzzle cuando hay resultado en pantalla. */
    private void updatePuzzle(float tpf) {
        if (!puzzleOpen || puzzleResultTimer <= 0f) return;

        puzzleResultTimer -= tpf;
        if (puzzleResultTimer > 0f) return;

        if (puzzleResultCorrect) {
            puzzleSolved = true;
            hasGreenMedicine = true;
            closePuzzle();
            playSound(getObjectSound);
            System.out.println("Medicina verde obtenida.");
        } else {
            if (puzzleResultGeometry != null) {
                puzzleResultGeometry.removeFromParent();
                puzzleResultGeometry = null;
            }
            for (int index : selectedPuzzleIndexes) {
                Geometry geo = puzzleOptionGeometries.get(index);
                Vector3f pos = geo.getLocalTranslation();
                geo.setLocalTranslation(pos.x, pos.y - 14, pos.z);
            }
            selectedPuzzleIndexes.clear();
            puzzleResultCorrect = false;
        }
    }

    /** Abre el puzzle de terapia y desbloquea el mouse. */
    private void openTherapistPuzzle() {
        therapistPuzzleOpen = true;
        left = right = up = down = false;
        inputManager.setCursorVisible(true);

        therapistPuzzleNode.detachAllChildren();
        therapistPuzzlePosters.clear();
        therapistPuzzleRects.clear();

        float w = cam.getWidth();
        float h = cam.getHeight();

        // Fondo gris para que el jugador sepa que está dentro de un puzzle.
        Quad bgQuad = new Quad(w, h);
        Geometry bg = new Geometry("TherapistPuzzleBackground", bgQuad);
        Material bgMat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        bgMat.setColor("Color", new ColorRGBA(0.22f, 0.22f, 0.22f, 0.92f));
        bgMat.getAdditionalRenderState().setBlendMode(RenderState.BlendMode.Alpha);
        bg.setQueueBucket(RenderQueue.Bucket.Gui);
        bg.setMaterial(bgMat);
        bg.setLocalTranslation(0, 0, 0);
        therapistPuzzleNode.attachChild(bg);

        /*
         * Cada cartel está formado por 4 tiles del tileset terapist_puzzle.png.
         * Los números son los que me pasaste:
         * - cartel izquierdo: 1, 2, 9, 10
         * - cartel del medio: 3, 4, 11, 12   <-- correcto
         * - cartel derecho: 5, 6, 13, 14
         */
        addTherapistPosterOption(new int[]{1, 2, 9, 10}, w / 2f - 300, h / 2f - 80);
        addTherapistPosterOption(new int[]{3, 4, 11, 12}, w / 2f - 80,  h / 2f - 80);
        addTherapistPosterOption(new int[]{5, 6, 13, 14}, w / 2f + 140, h / 2f - 80);

        therapistPuzzleNode.setCullHint(Spatial.CullHint.Inherit);
    }

    /**
     * Agrega un cartel 2x2 al puzzle de terapia.
     *
     * @param tiles arreglo con 4 tiles: arriba-izq, arriba-der, abajo-izq, abajo-der
     * @param x posición X donde aparece el cartel en pantalla
     * @param y posición Y donde aparece el cartel en pantalla
     */
    private void addTherapistPosterOption(int[] tiles, float x, float y) {
        float tileSize = 80f;
        float posterSize = tileSize * 2f;

        Node poster = new Node("TherapistPoster");

        // Arriba izquierda y arriba derecha.
        poster.attachChild(createTherapistPuzzleTileAt(tiles[0], 0, tileSize, tileSize, 10));
        poster.attachChild(createTherapistPuzzleTileAt(tiles[1], tileSize, tileSize, tileSize, 10));

        // Abajo izquierda y abajo derecha.
        poster.attachChild(createTherapistPuzzleTileAt(tiles[2], 0, 0, tileSize, 10));
        poster.attachChild(createTherapistPuzzleTileAt(tiles[3], tileSize, 0, tileSize, 10));

        poster.setLocalTranslation(x, y, 10);
        therapistPuzzleNode.attachChild(poster);

        therapistPuzzlePosters.add(poster);
        therapistPuzzleRects.add(new Rect(x, y, posterSize, posterSize));
    }

    /** Crea un tile del puzzle de terapia en una posición local dentro de un cartel. */
    private Geometry createTherapistPuzzleTileAt(int tileNumber, float localX, float localY,
                                                float size, float z) {
        Geometry tile = createTherapistPuzzleTileGeometry(tileNumber, size, "TherapistPuzzleTile" + tileNumber);
        tile.setLocalTranslation(localX, localY, z);
        return tile;
    }

    /** Maneja click sobre los carteles del puzzle de terapia. */
    private void handleTherapistPuzzleClick() {
        if (!therapistPuzzleOpen) return;

        Vector2f cursor = inputManager.getCursorPosition();

        for (int i = 0; i < therapistPuzzleRects.size(); i++) {
            Rect r = therapistPuzzleRects.get(i);
            if (cursor.x >= r.x && cursor.x <= r.x + r.w
                    && cursor.y >= r.y && cursor.y <= r.y + r.h) {
                selectTherapistPoster(i);
                return;
            }
        }
    }

    /** El cartel correcto es el del medio. Si acierta, obtiene la llave de doctores. */
    private void selectTherapistPoster(int index) {
        // 0 = izquierdo, 1 = medio correcto, 2 = derecho.
        if (index != 1) {
            Node poster = therapistPuzzlePosters.get(index);
            Vector3f p = poster.getLocalTranslation();
            poster.setLocalTranslation(p.x, p.y + 12, p.z);
            return;
        }

        Node correctPoster = therapistPuzzlePosters.get(index);
        Vector3f p = correctPoster.getLocalTranslation();
        correctPoster.removeFromParent();

        /*
         * Al seleccionar el cartel correcto, se arranca y aparece el cuadro
         * nuevo con los tiles 19, 20, 27 y 28.
         * Encima ponemos la llave pequeña, tile 33.
         */
        Node revealed = new Node("DoctorKeyReveal");
        float tileSize = 80f;

        revealed.attachChild(createTherapistPuzzleTileAt(19, 0, tileSize, tileSize, 25));
        revealed.attachChild(createTherapistPuzzleTileAt(20, tileSize, tileSize, tileSize, 25));
        revealed.attachChild(createTherapistPuzzleTileAt(27, 0, 0, tileSize, 25));
        revealed.attachChild(createTherapistPuzzleTileAt(28, tileSize, 0, tileSize, 25));

        Geometry smallKey = createTherapistPuzzleTileAt(33, 50, 45, 60, 40);
        revealed.attachChild(smallKey);

        revealed.setLocalTranslation(p.x, p.y, 25);
        therapistPuzzleNode.attachChild(revealed);

        therapistPuzzleSolved = true;
        hasDoctorsKey = true;
        playSound(getObjectSound);
        System.out.println("Llave pequeña obtenida. La habitación de doctores fue desbloqueada.");

        // Se queda visible un momento para que se note que el cartel se arrancó.
        therapistPuzzleCloseTimer = 1.2f;
    }

    /** Actualiza el cierre automático del puzzle de terapia después del acierto. */
    private void updateTherapistPuzzle(float tpf) {
        if (!therapistPuzzleOpen || therapistPuzzleCloseTimer <= 0f) {
            return;
        }

        therapistPuzzleCloseTimer -= tpf;
        if (therapistPuzzleCloseTimer <= 0f) {
            closeTherapistPuzzle();
        }
    }

    /** Cierra el puzzle de terapia y bloquea el mouse de nuevo. */
    private void closeTherapistPuzzle() {
        therapistPuzzleOpen = false;
        therapistPuzzleCloseTimer = 0f;
        if (therapistPuzzleNode != null) {
            therapistPuzzleNode.detachAllChildren();
            therapistPuzzleNode.setCullHint(Spatial.CullHint.Always);
        }
        if (inputManager != null && !puzzleOpen) {
            inputManager.setCursorVisible(false);
        }
    }

    private void initKeys() {
        inputManager.addMapping("Left", new KeyTrigger(KeyInput.KEY_A), new KeyTrigger(KeyInput.KEY_LEFT));
        inputManager.addMapping("Right", new KeyTrigger(KeyInput.KEY_D), new KeyTrigger(KeyInput.KEY_RIGHT));
        inputManager.addMapping("Up", new KeyTrigger(KeyInput.KEY_W), new KeyTrigger(KeyInput.KEY_UP));
        inputManager.addMapping("Down", new KeyTrigger(KeyInput.KEY_S), new KeyTrigger(KeyInput.KEY_DOWN));
        inputManager.addMapping("Interact", new KeyTrigger(KeyInput.KEY_E));
        inputManager.addMapping("ConfirmPuzzle", new KeyTrigger(KeyInput.KEY_RETURN));
        inputManager.addMapping("PuzzleClick", new MouseButtonTrigger(MouseInput.BUTTON_LEFT));

        inputManager.addListener(
                listener,
                "Left",
                "Right",
                "Up",
                "Down",
                "Interact",
                "ConfirmPuzzle",
                "PuzzleClick"
        );
    }

    private final ActionListener listener = (name, pressed, tpf) -> {
        if (name.equals("Left")) left = pressed;
        if (name.equals("Right")) right = pressed;
        if (name.equals("Up")) up = pressed;
        if (name.equals("Down")) down = pressed;

        if (name.equals("Interact") && pressed) {
            handleInteract();
        }

        if (name.equals("ConfirmPuzzle") && pressed) {
            confirmPuzzleCombination();
        }

        if (name.equals("PuzzleClick") && pressed) {
            if (therapistPuzzleOpen) {
                handleTherapistPuzzleClick();
            } else {
                handlePuzzleClick();
            }
        }
    };

    @Override
    public void simpleUpdate(float tpf) {
        boolean moving = false;

        updatePatientBubble(tpf);
        updatePuzzle(tpf);
        updateTherapistPuzzle(tpf);

        if (finalScreenOpen || prescriptionOpen || puzzleOpen || therapistPuzzleOpen) {
            updateRupertAnimation(tpf, false);
            updateInteractionPrompt();
            updateCamera();
            return;
        }

        if (!hidingUnderBed) {
            Vector3f pos = player.getLocalTranslation();
            moving = left || right || up || down;

            if (down) {
                currentDirection = Direction.FRONT;
            } else if (up) {
                currentDirection = Direction.BACK;
            } else if (right) {
                currentDirection = Direction.RIGHT;
            } else if (left) {
                currentDirection = Direction.LEFT;
            }

            Vector3f nextX = pos.clone();

            if (left) nextX.x -= SPEED * tpf;
            if (right) nextX.x += SPEED * tpf;

            if (canMoveTo(nextX)) {
                player.setLocalTranslation(nextX);
            }

            Vector3f nextY = player.getLocalTranslation().clone();

            if (up) nextY.y += SPEED * tpf;
            if (down) nextY.y -= SPEED * tpf;

            if (canMoveTo(nextY)) {
                player.setLocalTranslation(nextY);
            }

            checkExit();
            checkFinalReceptionDoors();
        }

        if (moving) {
            stepSoundTimer -= tpf;
            if (stepSoundTimer <= 0f) {
                playSound(stepSound);
                stepSoundTimer = 0.34f;
            }
        } else {
            stepSoundTimer = 0f;
        }

        updateRupertAnimation(tpf, moving);

        for (NurseEnemy nurse : nurseEnemies) {
            if (!scene.equals("HALLWAY") && !nurse.isChasing() && !nurse.isLeavingRoom()) {
                // Mientras Rupert está en un cuarto y no fue visto,
                // las enfermeras siguen patrullando en segundo plano.
                nurse.updateBackgroundPatrol(tpf);
            } else {
                boolean wasChasing = nurse.isChasing();

                boolean caught = nurse.update(
                        tpf,
                        player.getLocalTranslation(),
                        PLAYER_WIDTH,
                        PLAYER_HEIGHT,
                        currentCollision,
                        hidingUnderBed,
                        scene
                );

                if (!wasChasing && nurse.isChasing()) {
                    playSound(enemyVisionSound);
                }

                if (caught) {
                    restartGame();
                    return;
                }
            }
        }

        updateInteractionPrompt();
        updateCamera();
    }
}
